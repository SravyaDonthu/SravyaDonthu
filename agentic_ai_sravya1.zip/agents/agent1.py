# agent.py
import ssl
import os
import streamlit as st
import httpx
import json
import urllib3

from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent
from langchain_core.tools import tool

# -----------------------------
# Disable SSL warnings for corporate networks
# -----------------------------
ssl._create_default_https_context = ssl._create_unverified_context
os.environ["CURL_CA_BUNDLE"] = ""
os.environ["REQUESTS_CA_BUNDLE"] = ""
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# -----------------------------
# Your existing tools imports
# -----------------------------
from tools.log_parser_tool import parse_logs
from tools.metric_parser_tool import parse_metrics
from tools.anomaly_detection_tool import detect_anomalies
from tools.rag_tool import retrieve_context
from config import get_llm

# -----------------------------
# Global runtime state
# -----------------------------
_runtime_data = {}

# -----------------------------
# TOOL FUNCTIONS
# -----------------------------
def fetch_pipeline_data():
    logs = parse_logs()
    metrics = parse_metrics()
    anomalies = detect_anomalies()
    context = retrieve_context()
    return logs, metrics, anomalies, context

def generate_analysis_logic(query: str) -> str:
    logs, metrics, anomalies, context = fetch_pipeline_data()

    prompt = f"""
You are a senior data engineering AI investigator.

Pipeline Logs:
{logs}

Pipeline Metrics:
{metrics}

Detected Anomalies:
{anomalies}

Historical Knowledge:
{context}

User Query:
{query}

Provide response in this format:

Anomaly Summary
Metric Evidence
Root Cause
Impact
Recommended Solution
Prevention Strategy
Severity
"""
    llm_client = _runtime_data["llm"]
    response = llm_client.invoke(prompt)
    return response.content

# -----------------------------
# TOOLS
# -----------------------------
@tool
def AnalyzePipeline(query: str) -> str:
    """
    Analyze logs, metrics, anomalies and provide AI investigation summary.
    Returns a structured report as string.
    """
    return generate_analysis_logic(query)

tools = [AnalyzePipeline]

# -----------------------------
# LLM Client
# -----------------------------
llm = ChatOpenAI(
    model="azure/genailab-maas-gpt-4o-mini",
    api_key=os.environ.get("API_KEY", "sk-KC-vYapwC0EJlJIhaHjdVA"),
    base_url=os.environ.get("BASE_URL", "https://genailab.tcs.in"),
    temperature=0,
    http_client=httpx.Client(verify=False)
)

_runtime_data["llm"] = llm

# -----------------------------
# Agent
# -----------------------------
agent = create_react_agent(llm, tools)

# -----------------------------
# STREAMLIT UI
# -----------------------------
st.title("🤖 Agentic AI Anomaly Investigator")

query = st.text_area("Describe your query for anomaly investigation:")

if st.button("Run Analysis"):
    if not query.strip():
        st.error("Please enter a query for analysis.")
    else:
        with st.spinner("Agent is analyzing the pipeline..."):
            result = agent.invoke({
                "messages": [{"role": "user", "content": query}]
            })

        st.success("Analysis Completed")

        try:
            final_output = result["messages"][-1].content
            clean = final_output.strip().replace("```", "").strip()
            st.text_area("Investigation Report", clean, height=400)
        except Exception as e:
            st.warning(f"Could not parse output: {e}")
            st.write(result)