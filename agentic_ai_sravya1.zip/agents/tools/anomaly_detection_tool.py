import json
import pandas as pd
from sklearn.ensemble import IsolationForest

def detect_anomalies():

    with open("data/pipeline_metrics.json") as f:
        metrics = json.load(f)

    df = pd.DataFrame(metrics)

    features = df[
        ["records_processed","runtime_seconds","error_rate","cpu_usage","memory_usage"]
    ]

    model = IsolationForest(contamination=0.25)

    df["anomaly"] = model.fit_predict(features)

    anomalies = df[df["anomaly"] == -1]

    return anomalies.to_string()
