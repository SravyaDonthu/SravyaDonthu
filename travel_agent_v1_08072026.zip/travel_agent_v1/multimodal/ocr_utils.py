"""
multimodal/ocr_utils.py
-------------------------
OCR for scanned documents and photos of documents (boarding passes, visa
stamps, hotel vouchers) uploaded as images. Uses Tesseract via pytesseract;
requires the `tesseract-ocr` system package (installed in the Dockerfile).
"""

from PIL import Image, ImageOps
import pytesseract


def _preprocess(image: Image.Image) -> Image.Image:
    """Light preprocessing that meaningfully improves OCR accuracy on
    photographed (as opposed to flat-scanned) documents."""
    gray = ImageOps.grayscale(image)
    gray = ImageOps.autocontrast(gray)
    return gray


def ocr_image(image: Image.Image, lang: str = "eng") -> str:
    processed = _preprocess(image)
    return pytesseract.image_to_string(processed, lang=lang)


def ocr_image_file(file_path: str, lang: str = "eng") -> str:
    with Image.open(file_path) as img:
        return ocr_image(img, lang=lang)
