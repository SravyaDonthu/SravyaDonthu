"""
rag/vectordb.py
-----------------
Builds/loads a Chroma vector store over the destinations knowledge base
(travel tips, visa notes, seasonal advice) plus any user-uploaded documents
that were parsed by the document/OCR pipeline.

Swap Chroma for FAISS/Pinecone/Weaviate/Milvus by changing only this file -
`tools/rag_tool.py` and the agent never import Chroma directly.
"""

import os
import shutil
from functools import lru_cache
from langchain_community.vectorstores import Chroma
from langchain_text_splitters import RecursiveCharacterTextSplitter
from config import get_embeddings, VECTOR_DB_DIR, KNOWLEDGE_FILE

_vectordb = None


def _split_text(text: str):
    splitter = RecursiveCharacterTextSplitter(chunk_size=500, chunk_overlap=60)
    return splitter.split_text(text)


def build_vectordb(force_rebuild: bool = False):
    """Build (or load persisted) the base knowledge-base vector store."""
    global _vectordb
    if _vectordb is not None and not force_rebuild:
        return _vectordb

    embeddings = get_embeddings()

    has_persisted_store = os.path.isdir(VECTOR_DB_DIR) and any(
        f for f in os.listdir(VECTOR_DB_DIR) if not f.startswith(".")
    )

    if force_rebuild and has_persisted_store:
        # Wipe the stale persisted collection so rebuilding replaces rather
        # than duplicates old chunks (e.g. after editing destinations_knowledge.txt).
        for entry in os.listdir(VECTOR_DB_DIR):
            if entry.startswith("."):
                continue
            full = os.path.join(VECTOR_DB_DIR, entry)
            shutil.rmtree(full) if os.path.isdir(full) else os.remove(full)
        has_persisted_store = False

    if has_persisted_store and not force_rebuild:
        _vectordb = Chroma(persist_directory=VECTOR_DB_DIR, embedding_function=embeddings)
        return _vectordb

    with open(KNOWLEDGE_FILE) as f:
        text = f.read()

    docs = _split_text(text)
    _vectordb = Chroma.from_texts(
        docs,
        embedding=embeddings,
        persist_directory=VECTOR_DB_DIR,
        metadatas=[{"source": "destinations_knowledge_base"} for _ in docs],
    )
    return _vectordb


def add_documents(texts: list[str], source: str = "user_upload"):
    """
    Ingest extra text (e.g. from an uploaded PDF/image processed via OCR)
    into the same knowledge base so the agent can ground answers in it.
    """
    vectordb = build_vectordb()
    chunks = []
    for text in texts:
        chunks.extend(_split_text(text))
    if chunks:
        vectordb.add_texts(chunks, metadatas=[{"source": source} for _ in chunks])
    return len(chunks)


def similarity_search(query: str, k: int = 4):
    vectordb = build_vectordb()
    return vectordb.similarity_search(query, k=k)
