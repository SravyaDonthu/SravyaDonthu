"""
guardrails/output_guard.py
-----------------------------
Validates the *structured* itinerary summary the agent produces against a
schema (guardrails-ai + a .rail spec), the same pattern used by
`guardrails/log_guard.py` in the anomaly-detection agent this project is
based on. This catches cases where the LLM's JSON is malformed or missing
required fields before it's shown to the user or handed to the UI renderer.

If the `guardrails-ai` package or schema validation fails for any reason,
this degrades gracefully (returns the original payload with a warning)
rather than crashing the whole response - a hard guardrail failure should
never be the reason a user gets no answer at all.
"""

import json
import os

RAIL_PATH = os.path.join(os.path.dirname(__file__), "itinerary_validation_rail.xml")


def validate_itinerary_summary(summary: dict) -> dict:
    """
    summary must contain: destination_city, trip_days, total_budget_usd,
    estimated_total_cost_usd, daily_plan: [{day, summary}, ...]
    """
    try:
        from guardrails import Guard

        guard = Guard.from_rail(RAIL_PATH)
        validated, _extra = guard.parse(llm_output=json.dumps(summary))
        return {"valid": True, "data": validated}
    except Exception as e:
        # Fallback: basic manual schema check so the app keeps working even
        # without the guardrails-ai package installed / configured.
        required = ["destination_city", "trip_days", "total_budget_usd",
                    "estimated_total_cost_usd", "daily_plan"]
        missing = [k for k in required if k not in summary]
        if missing:
            return {"valid": False, "data": summary, "warning": f"Missing fields: {missing}"}
        return {"valid": True, "data": summary, "warning": f"guardrails-ai unavailable ({e}); used fallback schema check."}
