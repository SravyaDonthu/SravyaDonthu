"""
guardrails/input_guardrails.py
--------------------------------
Fast, deterministic pre-checks that run BEFORE a user query reaches the LLM
agent. These are cheap regex/keyword checks, not a second model call, so
they add negligible latency while catching the most common failure modes:

  1. Prompt injection ("ignore previous instructions", "reveal your system
     prompt", etc.)
  2. PII leakage risk (credit card numbers, passport numbers, national IDs
     pasted into chat) - flagged so the UI can warn the user before sending.
  3. Requests for unsafe/illegal travel facilitation (visa fraud, document
     forgery, smuggling, border evasion) - hard-blocked.
  4. Basic budget sanity (negative/zero/absurd numbers) - re-prompted rather
     than silently passed to the optimizer.

This is a defense-in-depth layer; the LLM's own alignment plus the system
prompt (see agents/travel_agent.py) is the second layer.
"""

import re
from dataclasses import dataclass, field

INJECTION_PATTERNS = [
    r"ignore (all|any|previous|the) instructions",
    r"disregard (all|any|previous|the) (system|prior) prompt",
    r"reveal (your|the) system prompt",
    r"you are now (in )?dan mode",
    r"pretend (you have|to have) no (restrictions|rules|guardrails)",
    r"act as if you have no (safety|content) polic",
]

UNSAFE_REQUEST_PATTERNS = [
    r"\bfake (visa|passport|id|documents?)\b",
    r"\bforge(d)? (visa|passport|travel documents?)\b",
    r"\bsmuggl(e|ing)\b",
    r"\bhuman trafficking\b",
    r"\bcross the border illegally\b",
    r"\bundetected by (customs|immigration|border)\b",
    r"\bvisa fraud\b",
    r"\bbribe (a )?(customs|immigration|border) officer\b",
]

CREDIT_CARD_PATTERN = r"\b(?:\d[ -]*?){13,16}\b"
PASSPORT_PATTERN = r"\b[A-PR-WYa-pr-wy][0-9]{7,9}\b"  # loose heuristic, not authoritative


@dataclass
class GuardrailResult:
    allowed: bool = True
    blocked_reason: str | None = None
    warnings: list = field(default_factory=list)
    redacted_text: str | None = None


def _matches_any(text: str, patterns: list) -> str | None:
    lowered = text.lower()
    for pattern in patterns:
        if re.search(pattern, lowered, flags=re.IGNORECASE):
            return pattern
    return None


def screen_input(user_text: str) -> GuardrailResult:
    result = GuardrailResult()

    if not user_text or not user_text.strip():
        result.allowed = False
        result.blocked_reason = "Empty query."
        return result

    injection_hit = _matches_any(user_text, INJECTION_PATTERNS)
    if injection_hit:
        result.allowed = False
        result.blocked_reason = "Request looks like a prompt-injection attempt and was blocked."
        return result

    unsafe_hit = _matches_any(user_text, UNSAFE_REQUEST_PATTERNS)
    if unsafe_hit:
        result.allowed = False
        result.blocked_reason = (
            "This request asks for help with unsafe or illegal travel facilitation "
            "(e.g. document fraud, smuggling, or evading border control), which this "
            "assistant cannot help with."
        )
        return result

    redacted = user_text
    if re.search(CREDIT_CARD_PATTERN, user_text):
        redacted = re.sub(CREDIT_CARD_PATTERN, "[REDACTED-CARD-NUMBER]", redacted)
        result.warnings.append(
            "It looks like you included a card number - it was redacted before being sent to the AI model."
        )
    if re.search(PASSPORT_PATTERN, redacted):
        result.warnings.append(
            "Your message may contain a passport/ID number. Consider removing it - "
            "it isn't needed to plan an itinerary."
        )

    result.redacted_text = redacted
    return result


def check_budget_sanity(budget_usd: float) -> GuardrailResult:
    result = GuardrailResult()
    if budget_usd is None or budget_usd <= 0:
        result.allowed = False
        result.blocked_reason = "Budget must be a positive number."
    elif budget_usd > 1_000_000:
        result.allowed = False
        result.blocked_reason = "That budget looks unrealistic - please double-check the amount."
    elif budget_usd < 30:
        result.warnings.append(
            "That budget is extremely low for most international itineraries; "
            "the plan may only cover a single city with minimal activities."
        )
    return result
