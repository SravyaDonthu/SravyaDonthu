"""
mcp_integration/mcp_server.py
-------------------
Exposes the travel tool functions (flights, hotels, activities, itinerary
optimizer, currency, budget, RAG) as a Model Context Protocol (MCP) server,
using the official `mcp` Python SDK (FastMCP).

Why this matters here: the same underlying tool functions are already
wired into the LangGraph agent as LangChain @tool objects (see
tools/*.py). Wrapping them again as an MCP server means ANY MCP-aware
client - Claude Desktop, another company's agent, an IDE assistant - can
discover and call this travel agent's capabilities over a standard
protocol, not just this Streamlit app. This is the "MCP" requirement:
function calling that is portable across agent frameworks/vendors.

Run standalone (stdio transport, e.g. for Claude Desktop config):
    python -m mcp_integration.mcp_server

Run over HTTP/SSE (for remote MCP clients):
    python -m mcp_integration.mcp_server --http
"""

import argparse
import json
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mcp.server.fastmcp import FastMCP  # noqa: E402  (mcp SDK, unrelated to this package's own name)

from tools.flight_search_tool import search_flights_raw
from tools.hotel_search_tool import search_hotels_raw
from tools.activity_search_tool import search_activities_raw
from tools.train_search_tool import search_trains_raw
from tools.itinerary_optimizer_tool import optimize_itinerary_raw
from tools.currency_tool import RATES
from tools.document_tool import ingest_document
from rag.vectordb import similarity_search

mcp = FastMCP("travel-itinerary-optimizer")


@mcp.tool()
def find_flights(origin: str, destination: str, max_price: float = 0, max_stops: int = -1) -> str:
    """Search flights between two IATA airport codes."""
    results = search_flights_raw(
        origin, destination,
        max_price=max_price if max_price > 0 else None,
        max_stops=max_stops if max_stops >= 0 else None,
    )
    return json.dumps(results[:8], indent=2)


@mcp.tool()
def find_hotels(city: str, max_price_per_night: float = 0, min_star_rating: int = 0) -> str:
    """Search hotels in a city by budget and star rating."""
    results = search_hotels_raw(
        city,
        max_price_per_night=max_price_per_night if max_price_per_night > 0 else None,
        min_star_rating=min_star_rating if min_star_rating > 0 else None,
    )
    return json.dumps(results[:8], indent=2)


@mcp.tool()
def find_trains(origin: str, destination: str, max_price_inr: float = 0, travel_class: str = "") -> str:
    """Search trains between two Indian cities/stations (INR fares by class)."""
    results = search_trains_raw(
        origin, destination,
        max_price=max_price_inr if max_price_inr > 0 else None,
        travel_class=travel_class or None,
    )
    return json.dumps(results[:8], indent=2)


@mcp.tool()
def find_activities(city: str, category: str = "") -> str:
    """Search attractions/activities in a city, optionally filtered by category."""
    return json.dumps(search_activities_raw(city, category or None), indent=2)


@mcp.tool()
def build_itinerary(city: str, days: int, budget_usd: float, preferred_categories: str = "") -> str:
    """Build a full optimized day-by-day itinerary with cost breakdown."""
    cats = [c.strip() for c in preferred_categories.split(",") if c.strip()] if preferred_categories else None
    return json.dumps(optimize_itinerary_raw(city, days, budget_usd, cats), indent=2, default=str)


@mcp.tool()
def convert_currency(amount: float, from_currency: str, to_currency: str) -> str:
    """Convert an amount between supported currencies (USD, EUR, GBP, JPY, INR, IDR, THB, AED)."""
    from_currency, to_currency = from_currency.upper(), to_currency.upper()
    if from_currency not in RATES or to_currency not in RATES:
        return json.dumps({"error": f"Unsupported pair {from_currency}->{to_currency}"})
    usd = amount / RATES[from_currency]
    return json.dumps({"converted_amount": round(usd * RATES[to_currency], 2), "to": to_currency})


@mcp.tool()
def search_travel_knowledge(query: str) -> str:
    """Query the RAG knowledge base (destination tips, visa notes, uploaded documents)."""
    docs = similarity_search(query, k=4)
    return json.dumps([{"source": d.metadata.get("source", "unknown"), "content": d.page_content} for d in docs], indent=2)


@mcp.tool()
def ingest_travel_document(file_path: str) -> str:
    """Extract text (with OCR fallback) from an uploaded PDF/image and add it to the knowledge base."""
    return json.dumps(ingest_document(file_path), indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--http", action="store_true", help="Serve over HTTP/SSE instead of stdio")
    args = parser.parse_args()

    if args.http:
        mcp.run(transport="sse")
    else:
        mcp.run(transport="stdio")
