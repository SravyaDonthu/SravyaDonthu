"""
agents/graph_state.py
------------------------
Shared state schema for the LangGraph orchestration graph in
agents/travel_agent.py.
"""

from typing import TypedDict, Optional, List, Any


class TravelGraphState(TypedDict, total=False):
    user_query: str
    session_context: str          # extra context: uploaded doc text, transcript
    chat_history: List[tuple]     # prior (role, text) turns from this session, oldest first
    blocked: bool
    block_reason: Optional[str]
    off_topic: bool
    warnings: List[str]
    messages: List[Any]           # LangGraph react-agent message history
    final_answer: str
