"""
agents/travel_agent.py
-------------------------
The core agentic system for the Travel Itinerary Optimizer.

Architecture (LangGraph StateGraph):

    START -> input_guardrail -> [blocked: injection/unsafe/PII?] -> END (refusal)
                              -> scope_guardrail -> [off-topic, e.g. non-travel
                                 general knowledge?] -> END (polite redirect)
                              -> react_agent (tool-calling loop: flights,
                                 trains, hotels, activities, itinerary
                                 optimizer, currency, budget check, RAG
                                 knowledge base, document ingestion - given
                                 the FULL prior chat history as message
                                 context, not just the latest turn)
                              -> output_guardrail -> END

`react_agent` itself is built with `langgraph.prebuilt.create_react_agent`
(also a StateGraph under the hood), giving the model autonomous multi-step
tool use: it decides which tools to call, in what order, and when it has
enough information to answer - this is the "AI Agents: autonomous task
execution" + "Function Calling" requirement.

This mirrors the structure of the anomaly-detection agent this project is
based on (config.get_llm(), a system-style prompt, tool functions in
tools/*.py) but generalizes it into a real multi-tool, multi-step graph
instead of a single fixed prompt.
"""

from langgraph.graph import StateGraph, END
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

from config import get_llm, get_fast_llm
from agents.graph_state import TravelGraphState
from guardrails.input_guardrails import screen_input

from tools.flight_search_tool import search_flights
from tools.hotel_search_tool import search_hotels
from tools.activity_search_tool import search_activities
from tools.train_search_tool import search_trains
from tools.itinerary_optimizer_tool import optimize_itinerary
from tools.currency_tool import convert_currency
from tools.budget_tool import check_budget
from tools.rag_tool import retrieve_travel_knowledge
from tools.document_tool import ingest_uploaded_document

SYSTEM_PROMPT = """You are an expert AI travel-planning agent inside a Travel \
Itinerary Optimizer application.

Your job: turn a traveler's natural-language request (destination(s), dates \
or trip length, budget, interests) into a concrete, optimized, multi-day \
itinerary with a clear cost breakdown.

Use your tools rather than guessing:
- search_flights / search_hotels / search_activities for live-style inventory
- search_trains for domestic/regional rail options (especially useful within
  India - e.g. Hyderabad to Kerala, or short hops like Ernakulam-Alleppey -
  where trains are often cheaper or the only practical option); always offer
  a train option alongside flights for domestic India routes, and compare
  them (duration, price, frequency) when the traveler asks train vs flight
- optimize_itinerary to assemble a day-by-day plan and cost estimate
- check_budget to verify the total (flights/trains + hotel + activities +
  buffer) fits the traveler's stated budget - if it doesn't, say so
  explicitly and suggest concrete trade-offs (fewer days, cheaper hotel
  tier, fewer paid activities, train instead of flight) rather than
  silently exceeding the budget
- convert_currency when the traveler asks about a non-USD currency (e.g.
  budgets given in INR)
- retrieve_travel_knowledge for seasonal advice, visa notes, local transit
  tips, or anything from documents the traveler has uploaded
- ingest_uploaded_document if the traveler references a file path for a
  document they just uploaded, so its content becomes searchable

If a city/route/place has no inventory in the tools, say so plainly and use
retrieve_travel_knowledge plus clearly-labeled general guidance instead of
silently going quiet - never just say "I couldn't find anything" with no
follow-up. For destinations near but not exactly matching tool data (e.g. a
town without its own airport), try the nearest hub city too.

You have access to the full prior conversation as message history - use it.
Do not ask the traveler to repeat details (destination, dates, budget,
group size, etc.) they already gave in an earlier turn.

Always structure your final answer with:
1. Trip Summary (destination, dates/length, traveler profile/interests)
2. Day-by-Day Itinerary (flights/trains, hotel, activities per day)
3. Cost Breakdown (transport, hotel, activities, buffer, grand total)
4. Budget Check (within budget? by how much? trade-off suggestions if not)
5. Practical Tips (from the knowledge base: season, visa, transit, packing)

Be transparent about anything you couldn't find real data for, and never \
invent specific real-world prices/flight/train numbers beyond what the \
tools returned - if tools return nothing, say so and offer alternatives.

DATA HONESTY: The flight/train/hotel names, numbers, and typical timings \
the tools return for well-covered routes are real (e.g. Sabari Express, \
IndiGo/Air India Express HYD-Kochi flights) - not fabricated. Prices, \
exact live timings, and seat availability are illustrative/approximate, \
not a live booking feed, so always tell the traveler to confirm the \
final price/time/availability on IRCTC (trains) or the airline/an OTA \
(flights) before booking.

SCOPE: You only help with travel planning - flights, trains, hotels, \
itineraries, budgets, destinations, visas, packing, and related logistics. \
If the traveler asks something unrelated to travel (general knowledge, \
politics, cooking, coding, etc.), briefly decline and steer back to travel \
planning; do not answer the off-topic question even if you know the answer.

Do not help with anything illegal (visa fraud, smuggling, forged documents, \
evading border control) - refuse and explain briefly if asked."""

TOOLS = [
    search_flights,
    search_hotels,
    search_activities,
    search_trains,
    optimize_itinerary,
    convert_currency,
    check_budget,
    retrieve_travel_knowledge,
    ingest_uploaded_document,
]


def _build_react_agent():
    llm = get_llm(temperature=0.2)
    return create_react_agent(llm, TOOLS, prompt=SYSTEM_PROMPT)


class TravelAgent:
    """Thin wrapper exposing a simple .run(query, context) API to the UI,
    backed by the LangGraph StateGraph defined in build_graph()."""

    def __init__(self):
        self._react_agent = _build_react_agent()
        self.graph = self._build_graph()

    # ---- graph nodes -----------------------------------------------------
    def _node_input_guardrail(self, state: TravelGraphState) -> TravelGraphState:
        result = screen_input(state["user_query"])
        state["warnings"] = list(result.warnings)
        if not result.allowed:
            state["blocked"] = True
            state["block_reason"] = result.blocked_reason
            state["final_answer"] = (
                f"I can't help with that request: {result.blocked_reason}"
            )
        else:
            state["blocked"] = False
            state["user_query"] = result.redacted_text or state["user_query"]
        return state

    def _node_scope_guardrail(self, state: TravelGraphState) -> TravelGraphState:
        """Classify whether the current turn is travel-related, using the
        conversation so far as context (so e.g. "ok proceed" after a travel
        question still counts as on-topic). Cheap, single fast-LLM call."""
        if state.get("blocked"):
            return state

        history = state.get("chat_history") or []
        recent = history[-6:]  # last few turns is enough context
        transcript = "\n".join(f"{role}: {text}" for role, text in recent)

        classifier_prompt = (
            "You are a strict scope classifier for a TRAVEL PLANNING assistant "
            "(flights, trains, hotels, itineraries, budgets, destinations, visas, "
            "packing, local transit, and directly related follow-ups like "
            "'ok proceed' or 'yes' in a travel conversation).\n\n"
            f"Recent conversation (may be empty):\n{transcript}\n\n"
            f"Latest user message: {state['user_query']}\n\n"
            "Is the LATEST user message travel-planning-related (including a "
            "short follow-up/confirmation to an ongoing travel conversation, or "
            "a greeting)? Answer with exactly one word: TRAVEL or OFF_TOPIC."
        )
        try:
            llm = get_fast_llm(temperature=0.0)
            verdict = llm.invoke([HumanMessage(content=classifier_prompt)]).content.strip().upper()
        except Exception:
            verdict = "TRAVEL"  # fail open on classifier errors, don't block the user

        if "OFF_TOPIC" in verdict:
            state["off_topic"] = True
            state["blocked"] = True
            state["final_answer"] = (
                "I'm your travel planning assistant, so I can only help with trips - "
                "flights, trains, hotels, itineraries, budgets, and destinations. "
                "Happy to help plan or adjust a trip whenever you're ready!"
            )
        else:
            state["off_topic"] = False
        return state

    def _node_react_agent(self, state: TravelGraphState) -> TravelGraphState:
        if state.get("blocked"):
            return state

        # Rebuild the full conversation as alternating Human/AI messages so
        # the agent has real memory of prior turns, instead of only ever
        # seeing the current message in isolation.
        messages = []
        for role, text in (state.get("chat_history") or []):
            if role == "user":
                messages.append(HumanMessage(content=text))
            else:
                messages.append(AIMessage(content=text))

        current_query = state["user_query"]
        if state.get("session_context"):
            current_query = (
                f"{state['user_query']}\n\n"
                f"[Additional context from uploaded documents]\n"
                f"{state['session_context']}"
            )
        messages.append(HumanMessage(content=current_query))

        result = self._react_agent.invoke({"messages": messages})
        state["messages"] = result["messages"]
        state["final_answer"] = result["messages"][-1].content
        return state

    def _node_output_guardrail(self, state: TravelGraphState) -> TravelGraphState:
        if state.get("blocked"):
            return state

        answer = state.get("final_answer", "")
        # Lightweight output-side safety net: strip accidental leakage of
        # system-prompt-like text and flag empty responses.
        if not answer or not answer.strip():
            state["final_answer"] = (
                "I wasn't able to generate a complete itinerary from the "
                "available tools - could you share a bit more detail (destination, "
                "trip length, and budget)?"
            )
        if state.get("warnings"):
            note = " ".join(state["warnings"])
            state["final_answer"] = f"{state['final_answer']}\n\n_Note: {note}_"
        return state

    def _build_graph(self):
        graph = StateGraph(TravelGraphState)
        graph.add_node("input_guardrail", self._node_input_guardrail)
        graph.add_node("scope_guardrail", self._node_scope_guardrail)
        graph.add_node("react_agent", self._node_react_agent)
        graph.add_node("output_guardrail", self._node_output_guardrail)

        graph.set_entry_point("input_guardrail")

        def route_after_input_guardrail(state: TravelGraphState):
            return "output_guardrail" if state.get("blocked") else "scope_guardrail"

        def route_after_scope_guardrail(state: TravelGraphState):
            return "output_guardrail" if state.get("blocked") else "react_agent"

        graph.add_conditional_edges("input_guardrail", route_after_input_guardrail,
                                     {"scope_guardrail": "scope_guardrail", "output_guardrail": "output_guardrail"})
        graph.add_conditional_edges("scope_guardrail", route_after_scope_guardrail,
                                     {"react_agent": "react_agent", "output_guardrail": "output_guardrail"})
        graph.add_edge("react_agent", "output_guardrail")
        graph.add_edge("output_guardrail", END)

        return graph.compile()

    # ---- public API --------------------------------------------------
    def run(self, query: str, session_context: str = "", chat_history: list | None = None) -> dict:
        initial_state: TravelGraphState = {
            "user_query": query,
            "session_context": session_context,
            "chat_history": chat_history or [],
            "warnings": [],
        }
        final_state = self.graph.invoke(initial_state)
        return {
            "answer": final_state.get("final_answer", ""),
            "blocked": final_state.get("blocked", False),
            "off_topic": final_state.get("off_topic", False),
            "warnings": final_state.get("warnings", []),
        }


def build_agent() -> TravelAgent:
    return TravelAgent()
