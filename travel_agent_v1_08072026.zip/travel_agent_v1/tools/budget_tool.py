"""
budget_tool.py
----------------
Lightweight arithmetic tool that lets the LLM check whether a proposed plan
fits inside the traveler's stated budget, instead of relying on the model's
own mental arithmetic (a common source of hallucinated totals).
"""

import json
from langchain_core.tools import tool


@tool
def check_budget(flight_cost_usd: float, hotel_cost_usd: float, activity_cost_usd: float,
                  misc_buffer_pct: float, total_budget_usd: float) -> str:
    """
    Sum flight + hotel + activity costs, add a misc/transport buffer
    (as a percentage of the subtotal), and compare against the traveler's
    total budget. Returns whether the plan is within budget and by how much.
    """
    subtotal = flight_cost_usd + hotel_cost_usd + activity_cost_usd
    buffer_amount = subtotal * (misc_buffer_pct / 100.0)
    grand_total = subtotal + buffer_amount
    within_budget = grand_total <= total_budget_usd
    delta = round(total_budget_usd - grand_total, 2)

    return json.dumps({
        "flight_cost_usd": flight_cost_usd,
        "hotel_cost_usd": hotel_cost_usd,
        "activity_cost_usd": activity_cost_usd,
        "misc_buffer_usd": round(buffer_amount, 2),
        "grand_total_usd": round(grand_total, 2),
        "total_budget_usd": total_budget_usd,
        "within_budget": within_budget,
        "surplus_or_deficit_usd": delta,
    })
