"""
rag_tool.py
------------
Exposes the knowledge-base retriever as a LangChain tool the agent can call
whenever it needs grounded travel knowledge (seasons, visas, local transit,
budgeting heuristics) rather than relying purely on parametric memory.
"""

import json
from langchain_core.tools import tool
from rag.vectordb import similarity_search


@tool
def retrieve_travel_knowledge(query: str) -> str:
    """
    Retrieve grounded travel knowledge (best season to visit, transit tips,
    visa notes, budgeting heuristics, and any traveler-uploaded document
    content) relevant to the query, from the vector knowledge base.
    """
    docs = similarity_search(query, k=4)
    if not docs:
        return json.dumps({"message": "No relevant knowledge base entries found."})
    results = [{"source": d.metadata.get("source", "unknown"), "content": d.page_content} for d in docs]
    return json.dumps(results, indent=2)
