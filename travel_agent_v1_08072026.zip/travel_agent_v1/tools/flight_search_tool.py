"""
flight_search_tool.py
----------------------
Searches the synthetic flight inventory. Structured to be a drop-in
replacement point for a real GDS/flight API (Amadeus, Skyscanner, Duffel):
swap the body of `_load_inventory` + filtering logic for a live HTTP call
and every caller (LangGraph agent, MCP server) keeps working unchanged.
"""

import json
import os
from typing import Optional
from langchain_core.tools import tool

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "synthetic_flights.json")


def _load_inventory():
    with open(DATA_PATH) as f:
        return json.load(f)


def search_flights_raw(origin: str, destination: str, max_price: Optional[float] = None,
                        max_stops: Optional[int] = None):
    flights = _load_inventory()
    origin = (origin or "").strip().upper()
    destination = (destination or "").strip().upper()

    results = [
        f for f in flights
        if (not origin or f["origin"] == origin)
        and (not destination or f["destination"] == destination)
    ]

    if max_price is not None:
        results = [f for f in results if f["price_usd"] <= max_price]
    if max_stops is not None:
        results = [f for f in results if f["stops"] <= max_stops]

    results = sorted(results, key=lambda f: (f["price_usd"], f["duration_min"]))
    return results


@tool
def search_flights(origin: str, destination: str, max_price: float = 0, max_stops: int = -1) -> str:
    """
    Search flights between two IATA airport codes (e.g. HYD, DEL, DXB, CDG, NRT, JFK, LHR).
    max_price: optional USD ceiling (0 = no limit).
    max_stops: optional max number of stops (-1 = no limit).
    Returns a JSON string list of matching flights sorted by price then duration.
    """
    results = search_flights_raw(
        origin, destination,
        max_price=max_price if max_price > 0 else None,
        max_stops=max_stops if max_stops >= 0 else None,
    )
    if not results:
        return json.dumps({"message": f"No flights found from {origin} to {destination} matching filters."})
    return json.dumps(results[:8], indent=2)
