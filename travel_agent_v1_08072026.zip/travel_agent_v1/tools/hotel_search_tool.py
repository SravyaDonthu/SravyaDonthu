"""
hotel_search_tool.py
---------------------
Searches synthetic hotel inventory by city / budget / minimum star rating.
Swap _load_inventory + filtering for a live API (Booking.com, Expedia Rapid,
Google Hotels) without touching the agent or MCP layer.
"""

import json
import os
from typing import Optional
from langchain_core.tools import tool

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "synthetic_hotels.json")


def _load_inventory():
    with open(DATA_PATH) as f:
        return json.load(f)


def search_hotels_raw(city: str, max_price_per_night: Optional[float] = None,
                       min_star_rating: Optional[int] = None):
    hotels = _load_inventory()
    city = (city or "").strip().lower()

    results = [h for h in hotels if not city or h["city"].lower() == city]

    if max_price_per_night is not None:
        results = [h for h in results if h["price_per_night_usd"] <= max_price_per_night]
    if min_star_rating is not None:
        results = [h for h in results if h["star_rating"] >= min_star_rating]

    results = sorted(results, key=lambda h: (-h["rating"], h["price_per_night_usd"]))
    return results


@tool
def search_hotels(city: str, max_price_per_night: float = 0, min_star_rating: int = 0) -> str:
    """
    Search hotels in a given city. max_price_per_night: USD ceiling (0 = no limit).
    min_star_rating: minimum star rating 1-5 (0 = no limit).
    Returns a JSON string list of matching hotels sorted by guest rating then price.
    """
    results = search_hotels_raw(
        city,
        max_price_per_night=max_price_per_night if max_price_per_night > 0 else None,
        min_star_rating=min_star_rating if min_star_rating > 0 else None,
    )
    if not results:
        return json.dumps({"message": f"No hotels found in {city} matching filters."})
    return json.dumps(results[:8], indent=2)
