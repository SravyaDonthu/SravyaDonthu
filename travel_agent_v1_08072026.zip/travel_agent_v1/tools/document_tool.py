"""
tools/document_tool.py
------------------------
Unifies document ingestion (PDF or image) -> text extraction (with OCR
fallback for scans) -> push into the RAG vector store, so uploaded booking
confirmations, visa letters, or itinerary drafts become part of what the
agent can ground its answers in.
"""

import os
import json
from langchain_core.tools import tool
from multimodal.pdf_utils import extract_text_from_pdf
from multimodal.ocr_utils import ocr_image_file
from rag.vectordb import add_documents

IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff"}


def ingest_document(file_path: str) -> dict:
    """
    Extract text from a PDF or image file and add it to the knowledge base.
    Returns metadata about what was extracted/ingested.
    """
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        result = extract_text_from_pdf(file_path)
        text = result["text"]
        meta = {"pages": result["pages"], "ocr_pages": result["ocr_pages"]}
    elif ext in IMAGE_EXTS:
        text = ocr_image_file(file_path)
        meta = {"ocr": True}
    elif ext in (".txt", ".md"):
        with open(file_path, encoding="utf-8", errors="ignore") as f:
            text = f.read()
        meta = {"ocr": False}
    else:
        return {"ingested": False, "error": f"Unsupported file type: {ext}"}

    if not text.strip():
        return {"ingested": False, "error": "No extractable text found in document.", **meta}

    chunk_count = add_documents([text], source=os.path.basename(file_path))
    return {"ingested": True, "chunks_added": chunk_count, "char_count": len(text), **meta}


@tool
def ingest_uploaded_document(file_path: str) -> str:
    """
    Ingest a previously uploaded travel document (PDF or image, e.g. a
    booking confirmation, visa letter, or hotel voucher) at the given local
    file path into the knowledge base so future questions can reference it.
    """
    result = ingest_document(file_path)
    return json.dumps(result, indent=2)
