"""
train_search_tool.py
----------------------
Searches the synthetic train inventory (Indian Railways-style, since a lot
of domestic India travel - e.g. Hyderabad -> Kerala, or Ernakulam ->
Alleppey - is done or finished by train rather than flight). Structured the
same way as flight_search_tool.py so it's a drop-in replacement point for a
real rail API (IRCTC/NTES) later: swap `_load_inventory` + filtering for a
live call and every caller (LangGraph agent, MCP server) keeps working.
"""

import json
import os
from typing import Optional
from langchain_core.tools import tool

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "synthetic_trains.json")


def _load_inventory():
    with open(DATA_PATH) as f:
        return json.load(f)


def search_trains_raw(origin: str, destination: str, max_price: Optional[float] = None,
                       travel_class: Optional[str] = None):
    trains = _load_inventory()
    origin = (origin or "").strip().lower()
    destination = (destination or "").strip().lower()

    results = [
        t for t in trains
        if (not origin or t["origin"].lower() == origin or t["origin_code"].lower() == origin)
        and (not destination or t["destination"].lower() == destination or t["destination_code"].lower() == destination)
    ]

    if travel_class:
        travel_class = travel_class.strip().lower()
        results = [t for t in results if travel_class in [c.lower() for c in t["classes"]]]

    if max_price is not None:
        results = [t for t in results if min(t["price_inr"].values()) <= max_price]

    results = sorted(results, key=lambda t: (min(t["price_inr"].values()), t["duration_min"]))
    return results


@tool
def search_trains(origin: str, destination: str, max_price_inr: float = 0, travel_class: str = "") -> str:
    """
    Search trains between two Indian cities/stations (e.g. "Hyderabad",
    "Ernakulam", "Alleppey", "Kochi", "Kottayam"). Use this for domestic
    India routes, especially within/near Kerala, where trains are often
    faster/cheaper/more available than flights.

    Returns REAL train names/numbers/typical timings (sourced from public
    railway schedules), not a live feed - fares, exact timings, and seat
    availability change and must be confirmed on IRCTC before booking.
    Entries with "verified": true are real, currently-operating services.

    max_price_inr: optional INR ceiling on the cheapest class (0 = no limit).
    travel_class: optional filter, e.g. "sleeper", "3a", "2a", "1a", "chair car".
    Returns a JSON string list of matching trains (with per-class INR prices)
    sorted by cheapest fare then duration.
    """
    results = search_trains_raw(
        origin, destination,
        max_price=max_price_inr if max_price_inr > 0 else None,
        travel_class=travel_class or None,
    )
    if not results:
        return json.dumps({
            "message": f"No trains found from {origin} to {destination} matching filters. "
                       f"Try nearby hub stations (e.g. Ernakulam/Kochi for Alleppey/Kumarakom)."
        })
    return json.dumps(results[:8], indent=2)
