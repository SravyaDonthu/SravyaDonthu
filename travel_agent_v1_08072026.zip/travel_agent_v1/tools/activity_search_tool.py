"""
activity_search_tool.py
------------------------
Searches synthetic attractions/activities inventory by city and category.
"""

import json
import os
from typing import Optional
from langchain_core.tools import tool

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "synthetic_activities.json")


def _load_inventory():
    with open(DATA_PATH) as f:
        return json.load(f)


def search_activities_raw(city: str, category: Optional[str] = None):
    activities = _load_inventory()
    city = (city or "").strip().lower()
    results = [a for a in activities if not city or a["city"].lower() == city]
    if category:
        category = category.strip().lower()
        results = [a for a in results if a["category"].lower() == category]
    results = sorted(results, key=lambda a: -a["rating"])
    return results


@tool
def search_activities(city: str, category: str = "") -> str:
    """
    Search things-to-do / attractions in a city. Optional category filter:
    culture, landmark, food, nature, art, entertainment, adventure.
    Returns a JSON string list of matching activities sorted by rating.
    """
    results = search_activities_raw(city, category or None)
    if not results:
        return json.dumps({"message": f"No activities found in {city} for category '{category}'."})
    return json.dumps(results, indent=2)
