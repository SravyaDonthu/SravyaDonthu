"""
itinerary_optimizer_tool.py
-----------------------------
The "optimization" core of the Travel Itinerary Optimizer.

Given a city, trip length, and total budget, this builds a day-by-day plan:
  1. Picks the best-rated hotel that fits the per-night budget share.
  2. Greedily fills each day (max ~8 active hours) with the highest-rated
     activities that still fit the remaining budget, avoiding category
     repeats on the same day for variety.
  3. Produces a full cost breakdown (flights are priced separately via
     search_flights and summed in by the agent / budget tool).

This is intentionally a transparent, explainable heuristic (not a black-box
model) so the AI agent can narrate *why* an item was chosen or dropped -
important for the "detailed schedules and cost breakdowns" requirement.
"""

import json
from langchain_core.tools import tool
from tools.hotel_search_tool import search_hotels_raw
from tools.activity_search_tool import search_activities_raw


def optimize_itinerary_raw(city: str, days: int, budget_usd: float,
                            preferred_categories: list | None = None):
    days = max(1, int(days))
    hotel_budget_share = budget_usd * 0.45
    activity_budget_share = budget_usd * 0.40
    # remaining ~15% implicitly reserved for local transport/meals/misc

    per_night_ceiling = max(20, hotel_budget_share / days)
    hotels = search_hotels_raw(city, max_price_per_night=per_night_ceiling)
    chosen_hotel = hotels[0] if hotels else None
    if not chosen_hotel:
        # relax constraint: pick cheapest available hotel in the city
        all_hotels = search_hotels_raw(city)
        chosen_hotel = min(all_hotels, key=lambda h: h["price_per_night_usd"]) if all_hotels else None

    hotel_cost = (chosen_hotel["price_per_night_usd"] * days) if chosen_hotel else 0

    activities = search_activities_raw(city)
    if preferred_categories:
        preferred = {c.lower() for c in preferred_categories}
        activities = sorted(activities, key=lambda a: (a["category"].lower() not in preferred, -a["rating"]))

    plan = []
    remaining_budget = activity_budget_share
    used_ids = set()

    for day_num in range(1, days + 1):
        day_hours_used = 0.0
        day_items = []
        day_categories_used = set()

        for a in activities:
            key = a["name"]
            if key in used_ids:
                continue
            if a["category"] in day_categories_used:
                continue
            if day_hours_used + a["duration_hr"] > 8:
                continue
            if a["price_usd"] > remaining_budget:
                continue

            day_items.append(a)
            used_ids.add(key)
            day_categories_used.add(a["category"])
            day_hours_used += a["duration_hr"]
            remaining_budget -= a["price_usd"]

            if day_hours_used >= 6:
                break

        plan.append({
            "day": day_num,
            "activities": day_items,
            "hours_planned": day_hours_used,
            "day_activity_cost_usd": round(sum(x["price_usd"] for x in day_items), 2),
        })

    total_activity_cost = round(sum(d["day_activity_cost_usd"] for d in plan), 2)

    return {
        "city": city,
        "days": days,
        "hotel": chosen_hotel,
        "hotel_total_cost_usd": round(hotel_cost, 2),
        "daily_plan": plan,
        "total_activity_cost_usd": total_activity_cost,
        "budget_input_usd": budget_usd,
        "estimated_subtotal_usd": round(hotel_cost + total_activity_cost, 2),
        "note": "Flights and local transport/meals are estimated separately; "
                "~15% of the input budget is reserved as a misc/transport buffer.",
    }


@tool
def optimize_itinerary(city: str, days: int, budget_usd: float, preferred_categories: str = "") -> str:
    """
    Build an optimized day-by-day itinerary for a city: selects a hotel and
    fills each day with the best-rated activities that fit the remaining
    budget and a realistic daily time budget (~6-8 active hours/day).
    preferred_categories: optional comma-separated list, e.g. "culture,food".
    Returns a JSON string with the hotel choice, day-by-day plan, and cost breakdown.
    """
    cats = [c.strip() for c in preferred_categories.split(",") if c.strip()] if preferred_categories else None
    result = optimize_itinerary_raw(city, days, budget_usd, cats)
    return json.dumps(result, indent=2, default=str)
