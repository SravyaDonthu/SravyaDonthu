"""
currency_tool.py
------------------
Static FX table for demo purposes. Swap `RATES` lookups for a live FX API
(e.g. exchangerate.host, open.er-api.com) in production - the @tool
signature stays identical so the agent graph and MCP server need no changes.
"""

import json
from langchain_core.tools import tool

# Units of foreign currency per 1 USD (illustrative, not live rates)
RATES = {
    "USD": 1.0,
    "EUR": 0.93,
    "GBP": 0.79,
    "JPY": 156.0,
    "INR": 83.5,
    "IDR": 16200.0,
    "THB": 36.5,
    "AED": 3.67,
}


@tool
def convert_currency(amount: float, from_currency: str, to_currency: str) -> str:
    """
    Convert an amount between currencies using reference rates
    (USD, EUR, GBP, JPY, INR, IDR, THB, AED supported).
    """
    from_currency = from_currency.upper()
    to_currency = to_currency.upper()
    if from_currency not in RATES or to_currency not in RATES:
        return json.dumps({"error": f"Unsupported currency pair {from_currency}->{to_currency}"})

    usd_amount = amount / RATES[from_currency]
    converted = usd_amount * RATES[to_currency]
    return json.dumps({
        "amount": amount,
        "from": from_currency,
        "to": to_currency,
        "converted_amount": round(converted, 2),
    })
