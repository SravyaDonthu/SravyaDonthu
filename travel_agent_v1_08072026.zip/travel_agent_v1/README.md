# AI Travel Itinerary Optimizer (Agentic AI)

An agentic AI system that turns a natural-language, spoken, or document-backed
travel request into an optimized, multi-day itinerary with a full cost
breakdown — built on the same architectural pattern as the
Data-Pipeline-Anomaly-Investigator agent (`agentic_ai_sravya.zip`), generalized
into a real multi-tool, multi-modal LangGraph system.

## Problem statement it solves

> Travelers spend considerable time assembling multi-leg trips that balance
> convenience, cost, and personal preference. Existing platforms give static
> search results, not personalized, context-aware, natural-language itinerary
> planning. (See `Sample_Problem_Statement.txt`.)

## Concept -> implementation map

| Requested concept | Where it lives |
|---|---|
| AI Agents / Autonomous task execution | `agents/travel_agent.py` — LangGraph `create_react_agent` autonomously decides which tools to call and in what order |
| Agentic model / Chatbot | `app.py` chat tab, backed by the same agent |
| Function Calling | `tools/*.py` — 8 LangChain `@tool` functions (flights, hotels, activities, optimizer, currency, budget, RAG, document ingestion) |
| LangChain | Tool definitions, `ChatOpenAI`/`OpenAIEmbeddings` clients, `Chroma` vector store, text splitters |
| LangGraph | `agents/travel_agent.py` — explicit `StateGraph` (input guardrail → react agent → output guardrail) wrapping the tool-calling loop |
| RAG | `rag/vectordb.py` + `tools/rag_tool.py` — retrieval-augmented answers grounded in destination knowledge and uploaded documents |
| ChromaDB (swappable for FAISS/Pinecone/Weaviate/Milvus) | `rag/vectordb.py` — isolated in one module; swap the store without touching agents/tools |
| Knowledge DB | `data/destinations_knowledge.txt` seeded into the vector store, extensible via the Knowledge Base tab |
| MCP | `mcp_integration/mcp_server.py` — the same tool functions exposed as a standalone MCP server (stdio or HTTP/SSE) for any MCP-aware client |
| Guardrails | `guardrails/input_guardrails.py` (prompt-injection, PII, unsafe-request, budget-sanity screening) + `guardrails/output_guard.py` (schema validation via `guardrails-ai`) |
| Fine-Tuning | `finetuning/prepare_dataset.py` + `finetuning/README.md` — logging + JSONL export pipeline for domain adaptation |
| Multimodal AI (text, image, audio) | `multimodal/ocr_utils.py`, `multimodal/pdf_utils.py`, `multimodal/speech_to_text.py` |
| Speech to text | `multimodal/speech_to_text.py` (faster-whisper → openai-whisper → Google STT fallback chain) |
| Documents upload / PDF or image upload | Streamlit "Upload Documents" tab → `tools/document_tool.py` |
| OCR for scanned documents | `multimodal/ocr_utils.py` (pytesseract), auto-triggered per-page inside `multimodal/pdf_utils.py` when a PDF page has no real text layer |
| Streamlit UI | `app.py` — 4 tabs: Chat, Upload Documents, Voice Request, Knowledge Base |
| Docker deployment | `Dockerfile` + `docker-compose.yml` (UI service + separate MCP server service) |

## Architecture

```
                         ┌────────────────────────┐
   User (text / voice /  │   Streamlit UI (app.py) │
   uploaded document)    └───────────┬────────────┘
                                      │
                     transcript / extracted text / typed query
                                      │
                                      ▼
                     ┌───────────────────────────────┐
                     │  LangGraph StateGraph          │
                     │  (agents/travel_agent.py)      │
                     │                                │
                     │  input_guardrail                │
                     │        │ (blocked?) ──► refusal │
                     │        ▼                        │
                     │  react_agent (tool-calling loop)│
                     │   ├─ search_flights             │
                     │   ├─ search_hotels               │
                     │   ├─ search_activities            │
                     │   ├─ optimize_itinerary             │
                     │   ├─ check_budget                    │
                     │   ├─ convert_currency                  │
                     │   ├─ retrieve_travel_knowledge (RAG)     │
                     │   └─ ingest_uploaded_document              │
                     │        ▼                                    │
                     │  output_guardrail                            │
                     └───────────────────────────────┘
                                      │
                                      ▼
                         Structured itinerary answer
                         (trip summary, day-by-day plan,
                          cost breakdown, budget check, tips)

  Same tool layer, exposed separately over MCP:
  mcp_integration/mcp_server.py  ── stdio / HTTP-SSE ──► any MCP client
                                                          (Claude Desktop, etc.)
```

## Data

Synthetic inventories (`data/synthetic_flights.json`, `synthetic_hotels.json`,
`synthetic_activities.json`) stand in for real flight/hotel/activity APIs —
swap the loader in each `tools/*_tool.py` for a real GDS/OTA API call and every
downstream caller (agent, MCP server) keeps working unchanged. A curated
knowledge base (`data/destinations_knowledge.txt`: seasons, visas, transit
tips, budgeting heuristics) is embedded into ChromaDB for RAG.

## Setup

```bash
cd travel_agent
cp .env.example .env        # edit LLM_API_KEY / LLM_BASE_URL for your provider
pip install -r requirements.txt

# System deps for OCR / PDF rasterization / audio (skip if using Docker):
#   Debian/Ubuntu: sudo apt-get install tesseract-ocr poppler-utils ffmpeg
#   macOS:         brew install tesseract poppler ffmpeg

streamlit run app.py
```

### Run the MCP server standalone

```bash
python -m mcp_integration.mcp_server            # stdio transport (e.g. Claude Desktop)
python -m mcp_integration.mcp_server --http     # HTTP/SSE transport
```

### Docker

```bash
docker compose up --build
# UI:         http://localhost:8501
# MCP server: http://localhost:8765
```

## Guardrails in practice

- **Input side** (`guardrails/input_guardrails.py`): blocks prompt-injection
  attempts and requests for unsafe/illegal travel facilitation (forged
  documents, smuggling, evading border control); redacts card numbers and
  warns on likely passport/ID numbers; sanity-checks budget values.
- **Output side** (`guardrails/output_guard.py`): validates any structured
  itinerary JSON against `guardrails/itinerary_validation_rail.xml` using
  `guardrails-ai`, with a graceful manual-schema fallback if that package
  isn't available.
- **System-prompt level** (`agents/travel_agent.py`): the agent is instructed
  never to invent prices/flights beyond what tools return, and to refuse
  illegal-travel-facilitation requests directly.

## Success metrics (from the problem statement)

The itinerary optimizer's `check_budget` tool gives a concrete, auditable
"within budget / by how much" answer instead of a vague estimate, and the
day-by-day plan is generated deterministically from transparent heuristics
(see `tools/itinerary_optimizer_tool.py`) so a human can verify *why* a given
hotel/activity was chosen — directly supporting the stated 80%+ satisfaction
and 40% planning-time-reduction goals by making the plan explainable and fast
to iterate on ("swap out day 3's activity" is a single follow-up chat turn).

## Known limitations / what's mocked

- Flight/hotel/activity inventories are synthetic JSON, not live bookings —
  this is explicitly permitted by the problem statement's data-considerations
  section ("synthetic or anonymized data").
- No booking/payment flow is implemented (out of scope per the problem
  statement, which asks for booking *links* — the agent surfaces the chosen
  flight/hotel IDs so a real integration could wire deep-links to a real OTA).
- Fine-tuning is data-prep-and-export only (see `finetuning/README.md`) — an
  actual training job needs a real provider account and curated volume.
