# Fine-Tuning / Domain Adaptation

This app is designed to work well out-of-the-box with a general-purpose LLM
via prompting + RAG + tools (the LangGraph agent in `agents/travel_agent.py`).
Fine-tuning is the *optional* next step once you have real usage data, for:

- Locking in the exact 5-section itinerary output format without needing to
  repeat it in the system prompt every time.
- Teaching house style/tone specific to a travel agency's brand voice.
- Reducing token cost/latency by shrinking the system prompt once the model
  has "absorbed" the instructions.

## Pipeline

1. **Log real interactions.** Call `finetuning.prepare_dataset.log_interaction(query, answer)`
   after each successful (non-guardrail-blocked) turn in `agents/travel_agent.py`
   to accumulate `data/chat_logs.jsonl`.
2. **Curate.** Manually spot-check a sample; remove any low-quality or
   off-format examples. Aim for 50-200+ diverse, high-quality examples
   minimum before fine-tuning a chat model.
3. **Build the training file:**
   ```bash
   python -m finetuning.prepare_dataset
   ```
   This writes `finetuning/travel_agent_finetune.jsonl` in the standard
   OpenAI chat fine-tuning format.
4. **Submit to a fine-tuning API**, e.g.:
   ```bash
   openai api fine_tuning.jobs.create \
     -t finetuning/travel_agent_finetune.jsonl \
     -m gpt-4o-mini-2024-07-18
   ```
   or the equivalent Azure OpenAI fine-tuning endpoint, or a local
   LoRA/QLoRA run (e.g. via `peft` + `trl`) if using an open-weight model.
5. **Swap the model name** in `config.py` (`LLM_CHAT_MODEL` env var) once the
   fine-tuned model is ready, and re-benchmark against the base model on a
   held-out set of itinerary requests before rolling out.

No fine-tuning job is triggered automatically by this repo - that requires a
real provider account and a curated dataset of meaningful size. The pieces
above are the concrete, reusable scaffolding for when that data exists.
