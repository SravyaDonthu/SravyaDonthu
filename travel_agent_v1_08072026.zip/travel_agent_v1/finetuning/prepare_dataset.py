"""
finetuning/prepare_dataset.py
--------------------------------
Domain-specific model adaptation (the "Fine-Tuning" requirement) usually
happens OUTSIDE the running app: you export good interactions, curate them,
then submit them to whichever fine-tuning API your base model supports
(OpenAI fine-tuning, Azure OpenAI, or a local LoRA run for an open-weight
model). This script handles the data-preparation half of that pipeline:

  1. Reads logged conversations (each turn recorded to data/chat_logs.jsonl
     by the agent - see `log_interaction` below) and/or the synthetic
     itineraries in data/, and reshapes them into the standard
     chat fine-tuning JSONL format:
         {"messages": [{"role": "system", ...}, {"role": "user", ...},
                        {"role": "assistant", ...}]}
  2. Filters out anything blocked by guardrails or flagged low-quality.
  3. Writes finetuning/travel_agent_finetune.jsonl, ready to hand to:
       openai api fine_tuning.jobs.create -t travel_agent_finetune.jsonl -m <base_model>
     or an equivalent Azure OpenAI / local LoRA trainer.

This repo does not call a fine-tuning API directly (that requires a paid
job against a specific provider + real curated volume), but this script is
the concrete, runnable adaptation-pipeline piece asked for.
"""

import json
import os

SYSTEM_PROMPT = (
    "You are an expert AI travel-planning agent. Turn a traveler's request "
    "into a concrete, optimized, multi-day itinerary with a cost breakdown."
)

LOG_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "chat_logs.jsonl")
OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "travel_agent_finetune.jsonl")


def log_interaction(user_query: str, assistant_answer: str, blocked: bool = False):
    """Append one real interaction to the training log. Call this from the
    agent after a successful (non-blocked) turn to accumulate real examples
    over time."""
    if blocked:
        return
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "a") as f:
        f.write(json.dumps({"query": user_query, "answer": assistant_answer}) + "\n")


def build_finetune_jsonl(min_answer_length: int = 80):
    examples = []

    if os.path.exists(LOG_PATH):
        with open(LOG_PATH) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                row = json.loads(line)
                if len(row.get("answer", "")) < min_answer_length:
                    continue
                examples.append({
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": row["query"]},
                        {"role": "assistant", "content": row["answer"]},
                    ]
                })

    with open(OUTPUT_PATH, "w") as f:
        for ex in examples:
            f.write(json.dumps(ex) + "\n")

    print(f"Wrote {len(examples)} training examples to {OUTPUT_PATH}")
    return len(examples)


if __name__ == "__main__":
    build_finetune_jsonl()
