"""
multimodal/pdf_utils.py
-------------------------
Extracts text from uploaded PDFs (system manuals, runbooks, sparse legacy
documentation). If a page yields little/no extractable text (i.e. it's a
scanned image rather than a real text layer), it is rasterized and routed
through the OCR pipeline automatically.
"""

from pypdf import PdfReader
from pdf2image import convert_from_path
from multimodal.ocr_utils import ocr_image

MIN_CHARS_PER_PAGE = 20  # below this, assume the page is a scanned image


def extract_text_from_pdf(file_path: str) -> dict:
    """
    Returns {"text": full_text, "pages": n, "ocr_pages": [page_numbers_that_needed_ocr]}
    """
    reader = PdfReader(file_path)
    page_texts = []
    ocr_pages = []

    for i, page in enumerate(reader.pages):
        try:
            text = page.extract_text() or ""
        except Exception:
            text = ""

        if len(text.strip()) < MIN_CHARS_PER_PAGE:
            ocr_text = _ocr_pdf_page(file_path, i)
            if ocr_text.strip():
                text = ocr_text
                ocr_pages.append(i + 1)

        page_texts.append(text)

    full_text = "\n\n".join(page_texts).strip()
    return {"text": full_text, "pages": len(reader.pages), "ocr_pages": ocr_pages}


def _ocr_pdf_page(file_path: str, page_index: int) -> str:
    try:
        images = convert_from_path(file_path, first_page=page_index + 1, last_page=page_index + 1)
        if not images:
            return ""
        return ocr_image(images[0])
    except Exception as e:
        return f"[OCR failed for page {page_index + 1}: {e}]"
