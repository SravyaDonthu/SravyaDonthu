"""
multimodal/speech_to_text.py
------------------------------
Converts uploaded/recorded audio (spoken support requests, e.g. "I keep
getting an S0C7 error when I run the payroll batch job") into text for the
agent.

Tries backends in order of quality/speed, falling back gracefully so the
feature still works in constrained environments:
  1. faster-whisper (CTranslate2, fastest, fully local, no API key)
  2. openai-whisper (local, slower, no API key)
  3. SpeechRecognition + Google Web Speech API (needs internet, no key,
     lowest accuracy - last-resort fallback only)

The public function `transcribe_audio(file_path)` always returns a dict:
{"text": str, "backend": str, "error": Optional[str]}
"""

import os

_model_cache = {}


def _try_faster_whisper(file_path: str, model_size: str = "base"):
    from faster_whisper import WhisperModel

    if "faster_whisper" not in _model_cache:
        _model_cache["faster_whisper"] = WhisperModel(model_size, device="cpu", compute_type="int8")
    model = _model_cache["faster_whisper"]

    segments, _info = model.transcribe(file_path)
    text = " ".join(seg.text.strip() for seg in segments)
    return text.strip()


def _try_openai_whisper(file_path: str, model_size: str = "base"):
    import whisper

    if "whisper" not in _model_cache:
        _model_cache["whisper"] = whisper.load_model(model_size)
    model = _model_cache["whisper"]

    result = model.transcribe(file_path)
    return result.get("text", "").strip()


def _try_speech_recognition(file_path: str):
    import speech_recognition as sr

    recognizer = sr.Recognizer()
    with sr.AudioFile(file_path) as source:
        audio = recognizer.record(source)
    return recognizer.recognize_google(audio).strip()


def transcribe_audio(file_path: str, model_size: str = "base") -> dict:
    if not os.path.exists(file_path):
        return {"text": "", "backend": None, "error": f"File not found: {file_path}"}

    backends = [
        ("faster-whisper", lambda: _try_faster_whisper(file_path, model_size)),
        ("openai-whisper", lambda: _try_openai_whisper(file_path, model_size)),
        ("speech_recognition(google)", lambda: _try_speech_recognition(file_path)),
    ]

    last_error = None
    for name, fn in backends:
        try:
            text = fn()
            if text:
                return {"text": text, "backend": name, "error": None}
        except Exception as e:
            last_error = f"{name} failed: {e}"
            continue

    return {"text": "", "backend": None, "error": last_error or "All STT backends failed."}
