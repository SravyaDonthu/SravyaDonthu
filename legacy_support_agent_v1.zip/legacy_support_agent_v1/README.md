# Generative AI Chatbot for Legacy System User Support (Agentic AI)

An agentic AI system that turns a natural-language, spoken, or
screenshot-backed description of a legacy-system problem into clear,
context-aware resolution guidance — built on the same architectural pattern
as the Travel Itinerary Optimizer agent, generalized into a real multi-tool,
multi-modal LangGraph system for the legacy-IT-support domain.

## Problem statement it solves

> Users of legacy IT systems often face challenges navigating outdated
> interfaces and complex workflows, leading to frequent support requests.
> Legacy system documentation is sparse and jargon-heavy, making self-help
> difficult. Support teams are burdened with repetitive queries. Existing
> chatbots lack domain-specific knowledge and contextual understanding of
> legacy systems. (See `AI Friday Season 2 — Problem Statements: Generative
> AI Chatbot for Legacy System User Support`.)

## Concept -> implementation map

| Requested concept | Where it lives |
|---|---|
| AI Agents / Autonomous task execution | `agents/legacy_agent.py` — LangGraph `create_react_agent` autonomously decides which tools to call and in what order |
| Agentic model / Chatbot | `app.py` chat tab, backed by the same agent |
| Function Calling | `tools/*.py` — 8 LangChain `@tool` functions (FAQ search, ticket search, system status, resolution guide, escalation scoring, feedback capture, RAG, document ingestion) |
| LangChain | Tool definitions, `ChatOpenAI`/`OpenAIEmbeddings` clients, `Chroma` vector store, text splitters |
| LangGraph | `agents/legacy_agent.py` — explicit `StateGraph` (input guardrail → scope guardrail → react agent → output guardrail) wrapping the tool-calling loop |
| RAG | `rag/vectordb.py` + `tools/rag_tool.py` — retrieval-augmented answers grounded in legacy-system knowledge and uploaded documents |
| ChromaDB (swappable for FAISS/Pinecone/Weaviate/Milvus) | `rag/vectordb.py` — isolated in one module; swap the store without touching agents/tools |
| Knowledge DB | `data/legacy_systems_knowledge.txt` seeded into the vector store, extensible via the Knowledge Base tab |
| API access to legacy system status/data endpoints | `tools/system_status_tool.py` — simulated live status/health-check API, swappable for a real monitoring endpoint |
| Historical support tickets and resolutions | `tools/ticket_search_tool.py` + `data/synthetic_tickets.json` |
| MCP | `mcp_integration/mcp_server.py` — the same tool functions exposed as a standalone MCP server (stdio or HTTP/SSE) for any MCP-aware client |
| Guardrails | `guardrails/input_guardrails.py` (prompt-injection, PII/credential redaction, unsafe-access-request screening) + `guardrails/output_guard.py` (schema validation via `guardrails-ai`) |
| Fine-Tuning | `finetuning/prepare_dataset.py` + `finetuning/README.md` — logging + feedback-filtered JSONL export pipeline for domain adaptation |
| Multimodal AI (text, image, audio) | `multimodal/ocr_utils.py`, `multimodal/pdf_utils.py`, `multimodal/speech_to_text.py` |
| Speech to text | `multimodal/speech_to_text.py` (faster-whisper → openai-whisper → Google STT fallback chain) |
| Documents upload / PDF or image upload | Streamlit "Upload Documents" tab → `tools/document_tool.py` |
| OCR for scanned documents / error screenshots | `multimodal/ocr_utils.py` (pytesseract), auto-triggered per-page inside `multimodal/pdf_utils.py` when a PDF page has no real text layer |
| Feedback capture for continuous improvement | `tools/feedback_tool.py` + the in-chat feedback widget in `app.py`, logged to `data/feedback_log.jsonl` |
| Dialog management | `agents/legacy_agent.py` — full prior chat history is replayed into the react agent every turn |
| Streamlit UI | `app.py` — 3 tabs: Chat & Get Support, Upload Documents, Knowledge Base |
| Docker deployment | `Dockerfile` + `docker-compose.yml` (UI service + separate MCP server service) |

## Architecture

```
                         ┌───────────────────────────┐
   User (text / voice /  │  Streamlit UI (app.py)     │
   uploaded screenshot)  └────────────┬───────────────┘
                                       │
                     transcript / extracted text / typed query
                                       │
                                       ▼
                     ┌────────────────────────────────┐
                     │  LangGraph StateGraph            │
                     │  (agents/legacy_agent.py)        │
                     │                                  │
                     │  input_guardrail                 │
                     │        │ (blocked?) ──► refusal   │
                     │        ▼                          │
                     │  scope_guardrail                   │
                     │        │ (off-topic?) ──► redirect  │
                     │        ▼                             │
                     │  react_agent (tool-calling loop)      │
                     │   ├─ check_system_status                │
                     │   ├─ search_faq_articles                 │
                     │   ├─ search_support_tickets                │
                     │   ├─ build_resolution_guide                  │
                     │   ├─ check_escalation_needed                   │
                     │   ├─ record_feedback                             │
                     │   ├─ retrieve_legacy_knowledge (RAG)               │
                     │   └─ ingest_uploaded_document                        │
                     │        ▼                                             │
                     │  output_guardrail                                     │
                     └────────────────────────────────┘
                                       │
                                       ▼
                         Structured support answer
                       (what's happening, recommended
                        steps, confidence & source, next step)

  Same tool layer, exposed separately over MCP:
  mcp_integration/mcp_server.py  ── stdio / HTTP-SSE ──► any MCP client
                                                          (Claude Desktop, etc.)
```

## Data

Synthetic knowledge sources stand in for real enterprise systems — swap the
loader in each `tools/*_tool.py` for a real API call (a knowledge-base/CMS
API, an ITSM ticketing API, a monitoring/health-check endpoint) and every
downstream caller (agent, MCP server) keeps working unchanged:

- `data/synthetic_faqs.json` — curated FAQ/knowledge-base articles per system
- `data/synthetic_tickets.json` — historical resolved support tickets with
  real resolution steps
- `data/synthetic_system_status.json` — simulated live system/module status,
  uptime, and last-incident data
- `data/legacy_systems_knowledge.txt` — system overviews, jargon glossaries,
  and general troubleshooting heuristics, embedded into ChromaDB for RAG

Five representative legacy systems are modeled: a COBOL payroll mainframe
(TSO/ISPF, batch JCL), an AS/400 inventory management system (5250
green-screen), a Siebel 7.8 CRM (thick client + EIM batch), an Oracle Forms
billing system, and a CICS-based mainframe HR portal — chosen to cover the
common green-screen / thick-client / forms-based interface patterns real
legacy estates still run on.

## Setup

```bash
cd legacy_support_agent_v1
cp .env.example .env        # edit LLM_API_KEY / LLM_BASE_URL for your provider
pip install -r requirements.txt

# System deps for OCR / PDF rasterization / audio (skip if using Docker):
#   Debian/Ubuntu: sudo apt-get install tesseract-ocr poppler-utils ffmpeg
#   macOS:         brew install tesseract poppler ffmpeg

streamlit run app.py
```

### Run the MCP server standalone

```bash
python -m mcp_integration.mcp_server            # stdio transport (e.g. Claude Desktop)
python -m mcp_integration.mcp_server --http     # HTTP/SSE transport
```

### Docker

```bash
docker compose up --build
# UI:         http://localhost:8501
# MCP server: http://localhost:8765
```

## Guardrails in practice

- **Input side** (`guardrails/input_guardrails.py`): blocks prompt-injection
  attempts and requests to bypass authentication, share/request credentials,
  disable security controls, or exploit a system's known vulnerabilities;
  redacts card numbers and passwords, and warns on likely employee/national
  ID numbers.
- **Scope side** (`agents/legacy_agent.py` `scope_guardrail` node): a cheap
  fast-LLM classifier keeps the conversation on legacy-system support,
  redirecting off-topic questions rather than answering them.
- **Output side** (`guardrails/output_guard.py`): validates any structured
  resolution-summary JSON against `guardrails/response_validation_rail.xml`
  using `guardrails-ai`, with a graceful manual-schema fallback if that
  package isn't available.
- **System-prompt level** (`agents/legacy_agent.py`): the agent is instructed
  never to invent error-code meanings or resolution steps beyond what the
  tools returned, to check system status before troubleshooting individual
  users, and to refuse unauthorized-access-facilitation requests directly.

## Success metrics (from the problem statement)

`build_resolution_guide` gives a transparent, auditable answer — which FAQ
or historical ticket it matched, and a confidence level — instead of an
opaque generated response, so a human can verify *why* a given resolution
was suggested. `check_escalation_needed` gives the same auditability for
hand-offs: a concrete score and threshold rather than a vague judgment call.
Combined with the in-chat feedback widget (`tools/feedback_tool.py`)
logging real satisfaction ratings, this directly supports measuring against
the stated 85%+ user satisfaction and 40% support-ticket-reduction goals,
and gives a continuous-improvement loop (poorly rated interactions are
excluded from the fine-tuning export in `finetuning/prepare_dataset.py`).

## Known limitations / what's mocked

- FAQ, ticket, and system-status data are synthetic JSON, not live
  ITSM/monitoring feeds — this is explicitly permitted by the problem
  statement's data-considerations section ("synthetic or anonymized data").
- No write-back to a real ticketing system is implemented (e.g. actually
  opening/closing a ServiceNow ticket) — out of scope for the prototype;
  `tools/ticket_search_tool.py` and `tools/feedback_tool.py` are the
  concrete integration points where that write-back would plug in.
- Fine-tuning is data-prep-and-export only (see `finetuning/README.md`) — an
  actual training job needs a real provider account and curated volume.
