"""
finetuning/prepare_dataset.py
--------------------------------
Domain-specific model adaptation (the "Fine-Tuning" requirement) usually
happens OUTSIDE the running app: you export good interactions, curate them,
then submit them to whichever fine-tuning API your base model supports
(OpenAI fine-tuning, Azure OpenAI, or a local LoRA run for an open-weight
model). This script handles the data-preparation half of that pipeline:

  1. Reads logged conversations (each turn recorded to data/chat_logs.jsonl
     by the agent - see `log_interaction` below) and/or feedback ratings in
     data/feedback_log.jsonl, and reshapes them into the standard chat
     fine-tuning JSONL format:
         {"messages": [{"role": "system", ...}, {"role": "user", ...},
                        {"role": "assistant", ...}]}
  2. Filters out anything blocked by guardrails, flagged low-quality, or
     rated poorly (satisfaction_rating <= 2) by an end user.
  3. Writes finetuning/legacy_support_finetune.jsonl, ready to hand to:
       openai api fine_tuning.jobs.create -t legacy_support_finetune.jsonl -m <base_model>
     or an equivalent Azure OpenAI / local LoRA trainer.

This repo does not call a fine-tuning API directly (that requires a paid
job against a specific provider + real curated volume), but this script is
the concrete, runnable adaptation-pipeline piece asked for.
"""

import json
import os

SYSTEM_PROMPT = (
    "You are an expert AI support agent for legacy IT system users. Turn a "
    "user's issue description into clear, concrete, context-aware "
    "resolution guidance grounded in FAQ articles, ticket history, and "
    "system status."
)

LOG_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "chat_logs.jsonl")
FEEDBACK_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "feedback_log.jsonl")
OUTPUT_PATH = os.path.join(os.path.dirname(__file__), "legacy_support_finetune.jsonl")


def log_interaction(user_query: str, assistant_answer: str, blocked: bool = False):
    """Append one real interaction to the training log. Call this from the
    agent after a successful (non-blocked) turn to accumulate real examples
    over time."""
    if blocked:
        return
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "a") as f:
        f.write(json.dumps({"query": user_query, "answer": assistant_answer}) + "\n")


def _low_rated_queries(min_rating: int = 3) -> set:
    """Best-effort set of queries/tickets tied to poor feedback, so we can
    exclude likely-bad examples from the training set. Feedback entries are
    keyed loosely (by ticket_ref/system), so this is a coarse filter."""
    low_rated = set()
    if not os.path.exists(FEEDBACK_PATH):
        return low_rated
    with open(FEEDBACK_PATH) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            row = json.loads(line)
            if row.get("satisfaction_rating", 5) <= 2 or row.get("resolved") is False:
                if row.get("ticket_ref"):
                    low_rated.add(row["ticket_ref"])
    return low_rated


def build_finetune_jsonl(min_answer_length: int = 80):
    examples = []
    low_rated = _low_rated_queries()

    if os.path.exists(LOG_PATH):
        with open(LOG_PATH) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                row = json.loads(line)
                if len(row.get("answer", "")) < min_answer_length:
                    continue
                if row.get("ticket_ref") in low_rated:
                    continue
                examples.append({
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": row["query"]},
                        {"role": "assistant", "content": row["answer"]},
                    ]
                })

    with open(OUTPUT_PATH, "w") as f:
        for ex in examples:
            f.write(json.dumps(ex) + "\n")

    print(f"Wrote {len(examples)} training examples to {OUTPUT_PATH}")
    return len(examples)


if __name__ == "__main__":
    build_finetune_jsonl()
