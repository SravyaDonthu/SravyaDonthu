"""
faq_search_tool.py
--------------------
Searches the synthetic FAQ/knowledge-article inventory for a legacy system
by name and free-text keyword. Structured to be a drop-in replacement point
for a real knowledge-base/CMS API (Confluence, ServiceNow KB, SharePoint):
swap the body of `_load_inventory` + filtering logic for a live HTTP call
and every caller (LangGraph agent, MCP server) keeps working unchanged.
"""

import json
import os
from typing import Optional
from langchain_core.tools import tool

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "synthetic_faqs.json")


def _load_inventory():
    with open(DATA_PATH) as f:
        return json.load(f)


def _keyword_score(faq: dict, keyword: str) -> int:
    keyword = keyword.lower()
    haystack = f"{faq['question']} {faq['answer']} {faq['category']}".lower()
    return sum(1 for word in keyword.split() if word in haystack)


def search_faq_articles_raw(system: str, keyword: Optional[str] = None, category: Optional[str] = None):
    faqs = _load_inventory()
    system = (system or "").strip().lower()
    results = [f for f in faqs if not system or system in f["system"].lower()]

    if category:
        category = category.strip().lower()
        results = [f for f in results if f["category"].lower() == category]

    if keyword:
        results = [f for f in results if _keyword_score(f, keyword) > 0]
        results = sorted(results, key=lambda f: (-_keyword_score(f, keyword), -f["rating"]))
    else:
        results = sorted(results, key=lambda f: -f["rating"])

    return results


@tool
def search_faq_articles(system: str, keyword: str = "", category: str = "") -> str:
    """
    Search FAQ / knowledge-base articles for a given legacy system (e.g.
    "COBOL Payroll Mainframe", "AS/400 Inventory Management", "Legacy CRM
    (Siebel 7.8)", "Oracle Forms Billing System", "IBM Mainframe HR Portal
    (CICS)"). Optional free-text keyword (matched against the question and
    answer text) and category filter (login, access, error, workflow).
    Returns a JSON string list of matching FAQ articles sorted by relevance.
    """
    results = search_faq_articles_raw(system, keyword or None, category or None)
    if not results:
        return json.dumps({"message": f"No FAQ articles found for system '{system}' matching the given filters."})
    return json.dumps(results[:8], indent=2)
