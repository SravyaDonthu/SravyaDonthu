"""
ticket_search_tool.py
------------------------
Searches historical support-ticket resolutions for a legacy system.
Structured the same way as faq_search_tool.py so it's a drop-in replacement
point for a real ITSM API (ServiceNow, Jira Service Management, Remedy):
swap `_load_inventory` + filtering for a live call and every caller
(LangGraph agent, MCP server) keeps working unchanged.
"""

import json
import os
from typing import Optional
from langchain_core.tools import tool

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "synthetic_tickets.json")


def _load_inventory():
    with open(DATA_PATH) as f:
        return json.load(f)


def _keyword_score(ticket: dict, keyword: str) -> int:
    keyword = keyword.lower()
    haystack = f"{ticket['issue_summary']} {ticket['category']} {' '.join(ticket['resolution_steps'])}".lower()
    return sum(1 for word in keyword.split() if word in haystack)


def search_support_tickets_raw(system: str, keyword: Optional[str] = None,
                                category: Optional[str] = None, priority: Optional[str] = None):
    tickets = _load_inventory()
    system = (system or "").strip().lower()
    results = [t for t in tickets if not system or system in t["system"].lower()]

    if category:
        category = category.strip().lower()
        results = [t for t in results if t["category"].lower() == category]
    if priority:
        priority = priority.strip().lower()
        results = [t for t in results if t["priority"].lower() == priority]

    if keyword:
        results = [t for t in results if _keyword_score(t, keyword) > 0]
        results = sorted(results, key=lambda t: -_keyword_score(t, keyword))
    else:
        results = sorted(results, key=lambda t: t["resolution_time_hours"])

    return results


@tool
def search_support_tickets(system: str, keyword: str = "", category: str = "", priority: str = "") -> str:
    """
    Search historical, RESOLVED support tickets for a legacy system to find
    similar past issues and how they were fixed. keyword is matched against
    the issue summary, category, and resolution steps. category: login,
    access, error, workflow. priority: low, medium, high.
    Returns a JSON string list of matching tickets (with their resolution
    steps) sorted by relevance.
    """
    results = search_support_tickets_raw(system, keyword or None, category or None, priority or None)
    if not results:
        return json.dumps({"message": f"No historical tickets found for system '{system}' matching the given filters."})
    return json.dumps(results[:8], indent=2)
