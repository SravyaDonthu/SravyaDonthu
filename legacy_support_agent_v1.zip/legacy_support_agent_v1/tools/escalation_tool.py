"""
escalation_tool.py
---------------------
Lightweight, auditable scoring tool that lets the LLM decide whether a case
should be escalated to the human support team, instead of relying on the
model's own judgment call (a common source of either under- or
over-escalating). Mirrors the "check budget" pattern: deterministic
arithmetic over inputs the agent supplies from the conversation.
"""

import json
from langchain_core.tools import tool

SEVERITY_WEIGHTS = {"critical": 40, "high": 25, "medium": 10, "low": 0}
ESCALATION_THRESHOLD = 40


@tool
def check_escalation_needed(troubleshooting_attempts: int, issue_severity: str,
                             user_sentiment_score: float, self_service_resolved: bool) -> str:
    """
    Score whether a case should be escalated to the human support team.
    troubleshooting_attempts: number of self-service/chatbot troubleshooting
    steps already tried without success.
    issue_severity: "critical" (blocks a business-critical process like
    payroll or invoicing), "high", "medium", or "low".
    user_sentiment_score: 0-10, where lower means more frustrated (estimate
    from the tone of the conversation).
    self_service_resolved: true if the issue is already resolved.
    Returns a JSON string with the escalation score, threshold, and a clear
    escalate/continue recommendation with reasoning.
    """
    if self_service_resolved:
        return json.dumps({
            "escalation_score": 0,
            "threshold": ESCALATION_THRESHOLD,
            "escalate": False,
            "reason": "Issue already resolved via self-service; no escalation needed.",
        })

    severity_key = (issue_severity or "medium").strip().lower()
    severity_score = SEVERITY_WEIGHTS.get(severity_key, SEVERITY_WEIGHTS["medium"])

    attempts_score = 20 if troubleshooting_attempts >= 3 else (10 if troubleshooting_attempts == 2 else 0)
    sentiment_score = 20 if user_sentiment_score < 4 else (10 if user_sentiment_score < 6 else 0)

    total_score = severity_score + attempts_score + sentiment_score
    escalate = total_score >= ESCALATION_THRESHOLD

    reasons = []
    if severity_score:
        reasons.append(f"severity={severity_key} (+{severity_score})")
    if attempts_score:
        reasons.append(f"{troubleshooting_attempts} troubleshooting attempts (+{attempts_score})")
    if sentiment_score:
        reasons.append(f"low user sentiment score {user_sentiment_score} (+{sentiment_score})")
    reason_text = ", ".join(reasons) if reasons else "no significant escalation factors"

    return json.dumps({
        "escalation_score": total_score,
        "threshold": ESCALATION_THRESHOLD,
        "escalate": escalate,
        "reason": (
            f"Score {total_score} {'meets' if escalate else 'is below'} the escalation "
            f"threshold of {ESCALATION_THRESHOLD} ({reason_text})."
        ),
    })
