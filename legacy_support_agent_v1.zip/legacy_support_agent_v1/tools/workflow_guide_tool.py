"""
workflow_guide_tool.py
-------------------------
The "optimization" core of the Legacy System Support Chatbot.

Given a system name and a description of the user's issue, this assembles a
concrete, step-by-step resolution guide by:
  1. Checking current system/module status first - if the relevant area is
     already known to be degraded/down, that's surfaced as the leading fact
     (no point troubleshooting a client-side cause of a server-side outage).
  2. Searching FAQ articles for the best keyword match.
  3. Searching historical resolved tickets for the closest similar issue.
  4. Merging these into a single ranked set of recommended steps, preferring
     the FAQ answer when one scores well (curated, reviewed content) and
     falling back to the most relevant ticket's resolution_steps otherwise.

This is intentionally a transparent, explainable heuristic (not a black-box
model) so the agent can narrate *why* a given guide was produced - important
for the "dialog management" and "context-aware assistance" requirements, and
so a human support agent can audit/correct it.
"""

import json
from langchain_core.tools import tool
from tools.faq_search_tool import search_faq_articles_raw, _keyword_score as _faq_score
from tools.ticket_search_tool import search_support_tickets_raw, _keyword_score as _ticket_score
from tools.system_status_tool import check_system_status_raw


def build_resolution_guide_raw(system: str, issue_description: str, category: str | None = None):
    status_records = check_system_status_raw(system)
    status = status_records[0] if status_records else None

    faqs = search_faq_articles_raw(system, issue_description, category)
    best_faq = faqs[0] if faqs else None
    best_faq_score = _faq_score(best_faq, issue_description) if best_faq else 0

    tickets = search_support_tickets_raw(system, issue_description, category)
    best_ticket = tickets[0] if tickets else None
    best_ticket_score = _ticket_score(best_ticket, issue_description) if best_ticket else 0

    # Prefer curated FAQ content when it's a reasonably strong match;
    # otherwise fall back to the closest resolved ticket's real steps.
    if best_faq and best_faq_score >= best_ticket_score and best_faq_score > 0:
        source = "faq"
        recommended_steps = [best_faq["answer"]]
        confidence = "high" if best_faq_score >= 2 else "medium"
    elif best_ticket and best_ticket_score > 0:
        source = "similar_ticket"
        recommended_steps = best_ticket["resolution_steps"]
        confidence = "high" if best_ticket_score >= 2 else "medium"
    else:
        source = "none"
        recommended_steps = [
            "No close FAQ or historical-ticket match was found for this exact issue.",
            "Gather: exact error code/message, the screen/menu/transaction being used, "
            "and whether other users are affected.",
            "If system status below shows a degraded/down module, this is likely the root "
            "cause rather than user error.",
        ]
        confidence = "low"

    degraded = bool(status and status["status"] != "operational")

    return {
        "system": system,
        "issue_description": issue_description,
        "current_status": status,
        "known_outage_relevant": degraded,
        "matched_faq": best_faq,
        "closest_similar_ticket": best_ticket,
        "recommendation_source": source,
        "recommended_steps": recommended_steps,
        "confidence": confidence,
    }


@tool
def build_resolution_guide(system: str, issue_description: str, category: str = "") -> str:
    """
    Build a step-by-step resolution guide for a user's legacy-system issue.
    Checks current system status first, then matches against FAQ articles
    and historical resolved tickets to produce ranked, explainable
    recommended steps with a confidence level (high/medium/low).
    category: optional filter - login, access, error, workflow.
    Returns a JSON string with the status check, matched sources, and
    recommended resolution steps.
    """
    result = build_resolution_guide_raw(system, issue_description, category or None)
    return json.dumps(result, indent=2, default=str)
