"""
system_status_tool.py
------------------------
Simulates API access to legacy-system status and health-monitoring
endpoints (the "API access to legacy system status and data endpoints"
data-consideration from the problem statement). Structured the same way as
the other search tools so it's a drop-in replacement point for a real
monitoring API (Nagios, Dynatrace, an internal ops dashboard): swap
`_load_status` for a live call and every caller keeps working unchanged.
"""

import json
import os
from typing import Optional
from langchain_core.tools import tool

DATA_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "synthetic_system_status.json")


def _load_status():
    with open(DATA_PATH) as f:
        return json.load(f)


def check_system_status_raw(system: Optional[str] = None):
    statuses = _load_status()
    if system:
        system = system.strip().lower()
        return [s for s in statuses if system in s["system"].lower()]
    return statuses


@tool
def check_system_status(system: str = "") -> str:
    """
    Check the current operational status of a legacy system (or all systems
    if left blank), including per-module status, 30-day uptime percentage,
    and the most recent known incident. Always check this BEFORE deep
    troubleshooting an individual user's error - if the relevant module is
    already known to be degraded/down, say so instead of walking the user
    through steps that won't help.
    Returns a JSON string list of matching system status records.
    """
    results = check_system_status_raw(system or None)
    if not results:
        return json.dumps({"message": f"No status record found for system '{system}'."})
    return json.dumps(results, indent=2)
