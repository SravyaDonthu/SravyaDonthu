"""
feedback_tool.py
-------------------
Captures end-user satisfaction feedback on a resolution, appending it to a
local log file. This directly supports the problem statement's "feedback
capture for continuous improvement" requirement and feeds the same
data/feedback_log.jsonl file that finetuning/prepare_dataset.py can later
fold into a curated fine-tuning set (which interactions were rated well vs.
poorly).

Swap the local JSONL append for a real feedback-store write (a database
table, a ServiceNow survey API, etc.) without touching the agent or MCP
layer.
"""

import json
import os
import time
from langchain_core.tools import tool

LOG_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "feedback_log.jsonl")


def record_feedback_raw(satisfaction_rating: int, resolved: bool, comments: str = "",
                         system: str = "", ticket_ref: str = ""):
    satisfaction_rating = max(1, min(5, int(satisfaction_rating)))
    entry = {
        "timestamp": time.time(),
        "system": system,
        "ticket_ref": ticket_ref,
        "satisfaction_rating": satisfaction_rating,
        "resolved": resolved,
        "comments": comments,
    }
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    with open(LOG_PATH, "a") as f:
        f.write(json.dumps(entry) + "\n")
    return entry


@tool
def record_feedback(satisfaction_rating: int, resolved: bool, comments: str = "",
                     system: str = "", ticket_ref: str = "") -> str:
    """
    Record the user's satisfaction feedback on the current support
    interaction. satisfaction_rating: 1 (very dissatisfied) to 5 (very
    satisfied). resolved: whether the user confirms their issue is fixed.
    Call this whenever a user explicitly rates the help they received or
    confirms/denies their issue is resolved, so it can be tracked for the
    85% satisfaction / 40% ticket-reduction success metrics.
    Returns a JSON string confirming what was logged.
    """
    entry = record_feedback_raw(satisfaction_rating, resolved, comments, system, ticket_ref)
    return json.dumps({"logged": True, **entry})
