"""
rag_tool.py
------------
Exposes the knowledge-base retriever as a LangChain tool the agent can call
whenever it needs grounded legacy-system knowledge (jargon glossaries,
navigation tips, general workflow guidance, and any user-uploaded manual or
screenshot content) rather than relying purely on parametric memory.
"""

import json
from langchain_core.tools import tool
from rag.vectordb import similarity_search


@tool
def retrieve_legacy_knowledge(query: str) -> str:
    """
    Retrieve grounded legacy-system knowledge (system overviews, jargon
    glossaries, navigation/workflow tips, general troubleshooting
    heuristics, and any content from documents the user has uploaded, e.g.
    a system manual or screenshot) relevant to the query, from the vector
    knowledge base.
    """
    docs = similarity_search(query, k=4)
    if not docs:
        return json.dumps({"message": "No relevant knowledge base entries found."})
    results = [{"source": d.metadata.get("source", "unknown"), "content": d.page_content} for d in docs]
    return json.dumps(results, indent=2)
