"""
mcp_integration/mcp_server.py
-------------------
Exposes the legacy-support tool functions (FAQ search, ticket search,
system status, resolution-guide builder, escalation scoring, feedback
capture, RAG) as a Model Context Protocol (MCP) server, using the official
`mcp` Python SDK (FastMCP).

Why this matters here: the same underlying tool functions are already
wired into the LangGraph agent as LangChain @tool objects (see
tools/*.py). Wrapping them again as an MCP server means ANY MCP-aware
client - Claude Desktop, another company's agent, an IDE assistant - can
discover and call this support agent's capabilities over a standard
protocol, not just this Streamlit app. This is the "MCP" requirement:
function calling that is portable across agent frameworks/vendors.

Run standalone (stdio transport, e.g. for Claude Desktop config):
    python -m mcp_integration.mcp_server

Run over HTTP/SSE (for remote MCP clients):
    python -m mcp_integration.mcp_server --http
"""

import argparse
import json
import sys
import os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from mcp.server.fastmcp import FastMCP  # noqa: E402  (mcp SDK, unrelated to this package's own name)

from tools.faq_search_tool import search_faq_articles_raw
from tools.ticket_search_tool import search_support_tickets_raw
from tools.system_status_tool import check_system_status_raw
from tools.workflow_guide_tool import build_resolution_guide_raw
from tools.escalation_tool import SEVERITY_WEIGHTS, ESCALATION_THRESHOLD
from tools.feedback_tool import record_feedback_raw
from tools.document_tool import ingest_document
from rag.vectordb import similarity_search

mcp = FastMCP("legacy-system-support-chatbot")


@mcp.tool()
def find_faq_articles(system: str, keyword: str = "", category: str = "") -> str:
    """Search FAQ/knowledge-base articles for a given legacy system."""
    return json.dumps(search_faq_articles_raw(system, keyword or None, category or None)[:8], indent=2)


@mcp.tool()
def find_support_tickets(system: str, keyword: str = "", category: str = "", priority: str = "") -> str:
    """Search historical resolved support tickets for a legacy system."""
    return json.dumps(
        search_support_tickets_raw(system, keyword or None, category or None, priority or None)[:8], indent=2
    )


@mcp.tool()
def get_system_status(system: str = "") -> str:
    """Check the current operational status of a legacy system (or all systems)."""
    return json.dumps(check_system_status_raw(system or None), indent=2)


@mcp.tool()
def get_resolution_guide(system: str, issue_description: str, category: str = "") -> str:
    """Build a ranked, step-by-step resolution guide for a legacy-system issue."""
    return json.dumps(build_resolution_guide_raw(system, issue_description, category or None), indent=2, default=str)


@mcp.tool()
def score_escalation(troubleshooting_attempts: int, issue_severity: str,
                      user_sentiment_score: float, self_service_resolved: bool) -> str:
    """Score whether a case should be escalated to the human support team."""
    if self_service_resolved:
        return json.dumps({"escalation_score": 0, "escalate": False})
    severity_score = SEVERITY_WEIGHTS.get((issue_severity or "medium").strip().lower(), SEVERITY_WEIGHTS["medium"])
    attempts_score = 20 if troubleshooting_attempts >= 3 else (10 if troubleshooting_attempts == 2 else 0)
    sentiment_score = 20 if user_sentiment_score < 4 else (10 if user_sentiment_score < 6 else 0)
    total = severity_score + attempts_score + sentiment_score
    return json.dumps({
        "escalation_score": total,
        "threshold": ESCALATION_THRESHOLD,
        "escalate": total >= ESCALATION_THRESHOLD,
    })


@mcp.tool()
def submit_feedback(satisfaction_rating: int, resolved: bool, comments: str = "",
                     system: str = "", ticket_ref: str = "") -> str:
    """Record end-user satisfaction feedback on a support interaction."""
    return json.dumps(record_feedback_raw(satisfaction_rating, resolved, comments, system, ticket_ref))


@mcp.tool()
def search_legacy_knowledge(query: str) -> str:
    """Query the RAG knowledge base (system overviews, glossaries, uploaded documents)."""
    docs = similarity_search(query, k=4)
    return json.dumps([{"source": d.metadata.get("source", "unknown"), "content": d.page_content} for d in docs], indent=2)


@mcp.tool()
def ingest_support_document(file_path: str) -> str:
    """Extract text (with OCR fallback) from an uploaded PDF/image and add it to the knowledge base."""
    return json.dumps(ingest_document(file_path), indent=2)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--http", action="store_true", help="Serve over HTTP/SSE instead of stdio")
    args = parser.parse_args()

    if args.http:
        mcp.run(transport="sse")
    else:
        mcp.run(transport="stdio")
