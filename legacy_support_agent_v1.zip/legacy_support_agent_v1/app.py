"""
app.py
-------
Streamlit front-end for the Generative AI Chatbot for Legacy System User
Support.

Tabs:
  1. Chat & Get Support - conversational agent (LangGraph + tool calling),
                           with an inline mic recorder (no separate audio tab)
                           and a quick satisfaction-feedback capture widget
  2. Upload Documents    - PDF/image upload (manuals, runbooks, error
                            screenshots), OCR for scans, ingested into RAG
  3. Knowledge Base      - inspect/add to the RAG vector store directly

Run:
    streamlit run app.py
"""

import os
import tempfile
import streamlit as st

from config import FEATURE_FLAGS
from agents.legacy_agent import build_agent
from multimodal.speech_to_text import transcribe_audio
from tools.document_tool import ingest_document
from tools.feedback_tool import record_feedback_raw
from rag.vectordb import similarity_search, add_documents, build_vectordb

SYSTEMS = [
    "COBOL Payroll Mainframe",
    "AS/400 Inventory Management",
    "Legacy CRM (Siebel 7.8)",
    "Oracle Forms Billing System",
    "IBM Mainframe HR Portal (CICS)",
]

st.set_page_config(page_title="Legacy System Support Chatbot", page_icon="🖥️", layout="wide")


# ---------------------------------------------------------------------------
# Cached / session resources
# ---------------------------------------------------------------------------
@st.cache_resource(show_spinner="Starting up the support agent...")
def get_agent():
    return build_agent()


if "chat_history" not in st.session_state:
    st.session_state.chat_history = []  # list of (role, text)
if "doc_context" not in st.session_state:
    st.session_state.doc_context = ""
if "pending_query" not in st.session_state:
    st.session_state.pending_query = ""
if "feedback_given" not in st.session_state:
    st.session_state.feedback_given = False


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
with st.sidebar:
    st.title("🖥️ Legacy Support Assistant")
    st.caption("Agentic AI · LangGraph · RAG · MCP · Multimodal")

    st.subheader("System status")
    for flag, enabled in FEATURE_FLAGS.items():
        st.write(("🟢" if enabled else "⚪") + " " + flag.replace("_", " ").title())

    st.divider()
    st.subheader("Quick-fill an issue (optional)")
    qf_system = st.selectbox("Legacy system", SYSTEMS)
    qf_category = st.selectbox("Category", ["error", "access", "workflow", "login"])
    qf_issue = st.text_area("Describe the issue", placeholder="e.g. Getting S0C7 abend on the payroll batch job")

    if st.button("Get help with this issue", use_container_width=True):
        query = (
            f"I'm using the {qf_system} and need help with a {qf_category} issue: {qf_issue}"
        )
        st.session_state.pending_query = query
        st.session_state.feedback_given = False

    st.divider()
    if st.button("Clear conversation", use_container_width=True):
        st.session_state.chat_history = []
        st.session_state.doc_context = ""
        st.session_state.feedback_given = False
        st.rerun()


tab_chat, tab_docs, tab_kb = st.tabs(
    ["💬 Chat & Get Support", "📄 Upload Documents", "📚 Knowledge Base"]
)


# ---------------------------------------------------------------------------
# Tab 1: Chat
# ---------------------------------------------------------------------------
with tab_chat:
    st.subheader("Get support")
    st.caption(
        "Describe your issue in plain language - which legacy system, what error "
        "or screen, and what you've already tried. The agent will check system "
        "status, search FAQs and past tickets, and build a resolution guide."
    )

    for role, text in st.session_state.chat_history:
        with st.chat_message(role):
            st.markdown(text)

    # st.chat_input auto-docks to the bottom of the page no matter where it's
    # called in the script, so it's safe to grab its value here.
    typed_query = st.chat_input("e.g. I get FRM-40735 when posting an invoice in the Oracle Forms billing system")
    query_to_run = st.session_state.pending_query or typed_query

    if query_to_run:
        st.session_state.pending_query = ""
        st.session_state.feedback_given = False
        # Snapshot history BEFORE appending the current turn, so the agent
        # gets real memory of everything said so far this session.
        history_so_far = list(st.session_state.chat_history)

        st.session_state.chat_history.append(("user", query_to_run))
        with st.chat_message("user"):
            st.markdown(query_to_run)

        with st.chat_message("assistant"):
            with st.spinner("Agent is checking system status, FAQs, and past tickets..."):
                agent = get_agent()
                result = agent.run(
                    query_to_run,
                    session_context=st.session_state.doc_context,
                    chat_history=history_so_far,
                )
            st.markdown(result["answer"])
            # Only genuine input-guardrail blocks (injection/unsafe/PII) are
            # shown as errors; an off-topic redirect is just a normal reply.
            if result.get("blocked") and not result.get("off_topic"):
                st.error("Request blocked by input guardrails.")
        st.session_state.chat_history.append(("assistant", result["answer"]))

    # --- Feedback capture: shown after at least one assistant turn, right
    # above the mic/input row, satisfying the "feedback capture for
    # continuous improvement" requirement from the problem statement.
    if st.session_state.chat_history and not st.session_state.feedback_given:
        st.divider()
        fb_col1, fb_col2, fb_col3 = st.columns([2, 2, 3])
        with fb_col1:
            fb_resolved = st.radio("Did this resolve your issue?", ["Not yet", "Yes"], horizontal=True, key="fb_resolved")
        with fb_col2:
            fb_rating = st.slider("Satisfaction (1-5)", 1, 5, 4, key="fb_rating")
        with fb_col3:
            fb_comments = st.text_input("Comments (optional)", key="fb_comments")
        if st.button("Submit feedback"):
            record_feedback_raw(
                satisfaction_rating=fb_rating,
                resolved=(fb_resolved == "Yes"),
                comments=fb_comments,
                system=qf_system,
            )
            st.session_state.feedback_given = True
            st.success("Thanks - your feedback was recorded.")

    # --- Inline mic recorder, rendered LAST so it stays near the bottom of
    # the page (just above the auto-pinned text box) instead of getting
    # stranded above older messages as the conversation grows. Unlike
    # st.chat_input, st.audio_input is a normal in-flow widget, so its
    # position in the script IS its position on screen.
    mic_col, hint_col = st.columns([1, 4])
    with mic_col:
        mic_audio = st.audio_input("🎙️ Speak", label_visibility="collapsed")
    with hint_col:
        st.caption("Tap the mic to speak your issue, or type in the box below.")

    if mic_audio is not None:
        audio_bytes = mic_audio.getvalue()
        audio_hash = hash(audio_bytes)
        # Only transcribe once per new recording (avoid re-transcribing on every rerun)
        if st.session_state.get("_last_mic_hash") != audio_hash:
            st.session_state["_last_mic_hash"] = audio_hash
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp:
                tmp.write(audio_bytes)
                tmp_path = tmp.name
            with st.spinner("Transcribing your voice request..."):
                stt_result = transcribe_audio(tmp_path)
            if stt_result["text"]:
                # Route through pending_query + rerun (same pattern as the
                # sidebar quick-fill) so the transcript is processed at the
                # top of the next run and the new messages render in the
                # normal history flow, above this mic widget.
                st.session_state.pending_query = stt_result["text"]
                st.rerun()
            else:
                st.error(stt_result.get("error", "Transcription failed - please try again or type your request."))


# ---------------------------------------------------------------------------
# Tab 2: Document / Image upload (PDF or image, OCR for scans)
# ---------------------------------------------------------------------------
with tab_docs:
    st.subheader("Upload system manuals, runbooks, or error screenshots")
    st.caption(
        "PDFs and images are supported. Scanned/photographed documents and "
        "screenshots of error dialogs are automatically routed through OCR. "
        "Extracted text is added to the knowledge base so the chat agent can "
        "reference it."
    )

    uploaded_file = st.file_uploader(
        "Upload a PDF or image", type=["pdf", "png", "jpg", "jpeg", "webp", "bmp", "tiff", "txt", "md"]
    )

    if uploaded_file is not None:
        with tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(uploaded_file.name)[1]) as tmp:
            tmp.write(uploaded_file.getvalue())
            tmp_path = tmp.name

        if uploaded_file.type and uploaded_file.type.startswith("image"):
            st.image(uploaded_file, caption=uploaded_file.name, width=350)

        if st.button("Extract & ingest into knowledge base"):
            with st.spinner("Extracting text (with OCR fallback for scans)..."):
                result = ingest_document(tmp_path)

            if result.get("ingested"):
                st.success(
                    f"Ingested {result['chunks_added']} chunk(s), {result['char_count']} characters."
                )
                if result.get("ocr_pages"):
                    st.info(f"OCR was used for page(s): {result['ocr_pages']}")
                elif result.get("ocr"):
                    st.info("OCR was used for this image.")
                st.session_state.doc_context += f"\n\n[From {uploaded_file.name}]\n(now searchable via the knowledge base)"
            else:
                st.error(result.get("error", "Could not extract text from this file."))


# ---------------------------------------------------------------------------
# Tab 3: Knowledge base explorer
# ---------------------------------------------------------------------------
with tab_kb:
    st.subheader("Knowledge base (RAG)")
    st.caption(
        "This is the same vector store (ChromaDB) the chat agent retrieves "
        "from - seeded with legacy-system overviews and jargon glossaries "
        "plus anything you've uploaded."
    )

    if st.button("🔄 Rebuild knowledge base from data/legacy_systems_knowledge.txt"):
        with st.spinner("Rebuilding vector store from the source knowledge file..."):
            build_vectordb(force_rebuild=True)
        st.success("Knowledge base rebuilt - newly added system content is now searchable.")

    kb_query = st.text_input("Test a knowledge-base search", placeholder="e.g. AEIB abend on CICS")
    if kb_query:
        with st.spinner("Searching knowledge base..."):
            docs = similarity_search(kb_query, k=4)
        for d in docs:
            with st.expander(f"Source: {d.metadata.get('source', 'unknown')}"):
                st.write(d.page_content)

    st.divider()
    st.write("Add custom knowledge (e.g. an internal runbook, or notes from a past incident):")
    custom_text = st.text_area("Text to add", height=100)
    if st.button("Add to knowledge base") and custom_text.strip():
        n = add_documents([custom_text], source="manual_entry")
        st.success(f"Added {n} chunk(s) to the knowledge base.")
