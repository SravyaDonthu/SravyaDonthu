"""
guardrails/input_guardrails.py
--------------------------------
Fast, deterministic pre-checks that run BEFORE a user query reaches the LLM
agent. These are cheap regex/keyword checks, not a second model call, so
they add negligible latency while catching the most common failure modes:

  1. Prompt injection ("ignore previous instructions", "reveal your system
     prompt", etc.)
  2. PII / credential leakage risk (passwords, credit card numbers,
     employee/national ID numbers pasted into chat) - flagged so the UI can
     warn the user before sending.
  3. Requests for unsafe/unauthorized access facilitation (bypassing
     authentication, sharing/requesting admin credentials, disabling
     security controls, exploiting a legacy system's known vulnerabilities,
     unauthorized data access) - hard-blocked.
  4. Basic sanity checks on numeric inputs (e.g. negative troubleshooting
     attempt counts) - re-prompted rather than silently passed to tools.

This is a defense-in-depth layer; the LLM's own alignment plus the system
prompt (see agents/legacy_agent.py) is the second layer.
"""

import re
from dataclasses import dataclass, field

INJECTION_PATTERNS = [
    r"ignore (all|any|previous|the) instructions",
    r"disregard (all|any|previous|the) (system|prior) prompt",
    r"reveal (your|the) system prompt",
    r"you are now (in )?dan mode",
    r"pretend (you have|to have) no (restrictions|rules|guardrails)",
    r"act as if you have no (safety|content) polic",
]

UNSAFE_REQUEST_PATTERNS = [
    r"\bbypass (login|authentication|the login|2fa|mfa)\b",
    r"\bwithout (logging in|authenticat(ing|ion))\b",
    r"\b(share|give|tell) me (the |an )?(admin|root|super ?user) password\b",
    r"\bdisable (security|access controls?|audit logging)\b",
    r"\bexploit(ing)? (a |the )?(vulnerabilit|known bug)\b",
    r"\bsql injection\b",
    r"\baccess (another user'?s?|someone else'?s?) (account|record|data) without authoriz",
    r"\bdelete (production|prod) data\b",
    r"\bcover(ing)? up (an |the )?(audit trail|change log)\b",
]

CREDIT_CARD_PATTERN = r"\b(?:\d[ -]*?){13,16}\b"
# Loose heuristic for employee/national ID or SSN-style numbers, not authoritative
ID_NUMBER_PATTERN = r"\b\d{3}-\d{2}-\d{4}\b|\b[A-Z]{2}\d{6,9}\b"
PASSWORD_PATTERN = r"\bpassword\s*(is|:)\s*\S+"


@dataclass
class GuardrailResult:
    allowed: bool = True
    blocked_reason: str | None = None
    warnings: list = field(default_factory=list)
    redacted_text: str | None = None


def _matches_any(text: str, patterns: list) -> str | None:
    lowered = text.lower()
    for pattern in patterns:
        if re.search(pattern, lowered, flags=re.IGNORECASE):
            return pattern
    return None


def screen_input(user_text: str) -> GuardrailResult:
    result = GuardrailResult()

    if not user_text or not user_text.strip():
        result.allowed = False
        result.blocked_reason = "Empty query."
        return result

    injection_hit = _matches_any(user_text, INJECTION_PATTERNS)
    if injection_hit:
        result.allowed = False
        result.blocked_reason = "Request looks like a prompt-injection attempt and was blocked."
        return result

    unsafe_hit = _matches_any(user_text, UNSAFE_REQUEST_PATTERNS)
    if unsafe_hit:
        result.allowed = False
        result.blocked_reason = (
            "This request asks for help bypassing authentication, sharing credentials, "
            "disabling security controls, or otherwise gaining unauthorized access to a "
            "legacy system, which this assistant cannot help with. Please route access "
            "requests through the proper access-request channel."
        )
        return result

    redacted = user_text
    if re.search(CREDIT_CARD_PATTERN, user_text):
        redacted = re.sub(CREDIT_CARD_PATTERN, "[REDACTED-CARD-NUMBER]", redacted)
        result.warnings.append(
            "It looks like you included a card number - it was redacted before being sent to the AI model."
        )
    if re.search(PASSWORD_PATTERN, redacted, flags=re.IGNORECASE):
        redacted = re.sub(PASSWORD_PATTERN, "password: [REDACTED]", redacted, flags=re.IGNORECASE)
        result.warnings.append(
            "It looks like you included a password - it was redacted before being sent to the AI model. "
            "Never share your actual password in chat, including with this assistant."
        )
    if re.search(ID_NUMBER_PATTERN, redacted):
        result.warnings.append(
            "Your message may contain an employee/national ID number. Consider removing it - "
            "it usually isn't needed to troubleshoot a system issue."
        )

    result.redacted_text = redacted
    return result


def check_attempts_sanity(troubleshooting_attempts: int) -> GuardrailResult:
    result = GuardrailResult()
    if troubleshooting_attempts is None or troubleshooting_attempts < 0:
        result.allowed = False
        result.blocked_reason = "Troubleshooting attempt count must be zero or a positive number."
    elif troubleshooting_attempts > 20:
        result.warnings.append(
            "That's an unusually high number of troubleshooting attempts - this should almost "
            "certainly be escalated to the human support team already."
        )
    return result
