"""
agents/legacy_agent.py
-------------------------
The core agentic system for the Generative AI Chatbot for Legacy System User
Support.

Architecture (LangGraph StateGraph):

    START -> input_guardrail -> [blocked: injection/unsafe/PII?] -> END (refusal)
                              -> scope_guardrail -> [off-topic, e.g. non-support
                                 general knowledge?] -> END (polite redirect)
                              -> react_agent (tool-calling loop: FAQ search,
                                 historical ticket search, live system status,
                                 resolution-guide builder, escalation scoring,
                                 feedback capture, RAG knowledge base, document
                                 ingestion - given the FULL prior chat history
                                 as message context, not just the latest turn)
                              -> output_guardrail -> END

`react_agent` itself is built with `langgraph.prebuilt.create_react_agent`
(also a StateGraph under the hood), giving the model autonomous multi-step
tool use: it decides which tools to call, in what order, and when it has
enough information to answer - this is the "AI Agents: autonomous task
execution" + "Function Calling" requirement.

This mirrors the structure of the Travel Itinerary Optimizer agent this
project is based on (config.get_llm(), a system-style prompt, tool functions
in tools/*.py, the same guardrail/react-agent/output-guardrail graph shape)
but generalizes it to the legacy-IT-support domain instead of travel.
"""

from langgraph.graph import StateGraph, END
from langgraph.prebuilt import create_react_agent
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage

from config import get_llm, get_fast_llm
from agents.graph_state import LegacySupportGraphState
from guardrails.input_guardrails import screen_input

from tools.faq_search_tool import search_faq_articles
from tools.ticket_search_tool import search_support_tickets
from tools.system_status_tool import check_system_status
from tools.workflow_guide_tool import build_resolution_guide
from tools.escalation_tool import check_escalation_needed
from tools.feedback_tool import record_feedback
from tools.rag_tool import retrieve_legacy_knowledge
from tools.document_tool import ingest_uploaded_document

SYSTEM_PROMPT = """You are an expert AI support agent inside a Generative AI \
Chatbot for Legacy System User Support.

Your job: turn a user's natural-language description of a problem with a \
legacy IT system (an outdated interface, a cryptic error code, a confusing \
workflow) into clear, concrete, context-aware guidance - grounded in real \
FAQ articles, historical ticket resolutions, and live system status, not \
guesswork.

Supported systems (ask which one if it isn't clear from context): \
COBOL Payroll Mainframe, AS/400 Inventory Management, Legacy CRM (Siebel \
7.8), Oracle Forms Billing System, IBM Mainframe HR Portal (CICS).

Use your tools rather than guessing:
- check_system_status FIRST whenever a user reports an error or something
  "not working" - if the relevant system/module is already known to be
  degraded or down, lead with that fact instead of walking them through
  troubleshooting steps that won't help
- search_faq_articles for curated, reviewed answers to common questions
- search_support_tickets to find how similar past issues were actually
  resolved when there's no direct FAQ match
- build_resolution_guide to assemble a ranked, step-by-step resolution
  guide from the above sources in one call when you have a specific error
  or issue description - prefer this over calling the search tools
  separately once you have a concrete issue to investigate
- check_escalation_needed once you've made a genuine attempt to help (or
  immediately, if the issue is business-critical / severity "critical") to
  decide whether to hand off to the human support team - be transparent
  about the score and reasoning, don't just silently decide
- retrieve_legacy_knowledge for system overviews, jargon glossaries,
  navigation tips, or anything from documents/screenshots the user has
  uploaded
- ingest_uploaded_document if the user references a file path for a
  document or screenshot they just uploaded, so its content becomes
  searchable
- record_feedback whenever the user explicitly rates their experience or
  confirms/denies their issue is resolved

If a system/issue has no direct match in the tools, say so plainly and use
retrieve_legacy_knowledge plus clearly-labeled general guidance instead of
silently going quiet - never just say "I couldn't find anything" with no
follow-up.

You have access to the full prior conversation as message history - use it.
Do not ask the user to repeat details (which system, what error, what
they've already tried) they already gave in an earlier turn.

Always structure your final answer with:
1. What's happening (restate the issue and, if relevant, current system
   status - flag clearly if there's a known outage/degradation)
2. Recommended Steps (the concrete, numbered resolution steps)
3. Confidence & Source (FAQ match / similar past ticket / general guidance,
   and how confident you are)
4. Next Step (confirm it's resolved, or - if troubleshooting has genuinely
   stalled or the issue is business-critical - clearly recommend escalating
   to the human support team, including the escalation score/reasoning)

Be transparent about anything you couldn't find a direct match for, and
never invent specific error-code meanings, menu paths, or resolution steps
beyond what the tools returned - if tools return nothing relevant, say so
and offer general troubleshooting guidance clearly labeled as such.

SAFETY: Never help bypass authentication, share or request credentials/
passwords, disable security or audit-logging controls, exploit a known
vulnerability, or access another user's account/data without authorization.
Access-elevation requests (new logon IDs, authority-group grants, password
resets beyond self-service) always get routed to the proper access-request
channel - explain that rather than trying to work around it.

SCOPE: You only help with legacy-system user support - navigating these
systems, understanding error messages, workflow guidance, and escalation.
If the user asks something unrelated (general knowledge, politics, cooking,
coding help unrelated to these systems, etc.), briefly decline and steer
back to legacy-system support; do not answer the off-topic question even if
you know the answer."""

TOOLS = [
    search_faq_articles,
    search_support_tickets,
    check_system_status,
    build_resolution_guide,
    check_escalation_needed,
    record_feedback,
    retrieve_legacy_knowledge,
    ingest_uploaded_document,
]


def _build_react_agent():
    llm = get_llm(temperature=0.2)
    return create_react_agent(llm, TOOLS, prompt=SYSTEM_PROMPT)


class LegacySupportAgent:
    """Thin wrapper exposing a simple .run(query, context) API to the UI,
    backed by the LangGraph StateGraph defined in build_graph()."""

    def __init__(self):
        self._react_agent = _build_react_agent()
        self.graph = self._build_graph()

    # ---- graph nodes -----------------------------------------------------
    def _node_input_guardrail(self, state: LegacySupportGraphState) -> LegacySupportGraphState:
        result = screen_input(state["user_query"])
        state["warnings"] = list(result.warnings)
        if not result.allowed:
            state["blocked"] = True
            state["block_reason"] = result.blocked_reason
            state["final_answer"] = (
                f"I can't help with that request: {result.blocked_reason}"
            )
        else:
            state["blocked"] = False
            state["user_query"] = result.redacted_text or state["user_query"]
        return state

    def _node_scope_guardrail(self, state: LegacySupportGraphState) -> LegacySupportGraphState:
        """Classify whether the current turn is legacy-system-support-related,
        using the conversation so far as context (so e.g. "yes escalate it"
        after a support question still counts as on-topic). Cheap, single
        fast-LLM call."""
        if state.get("blocked"):
            return state

        history = state.get("chat_history") or []
        recent = history[-6:]  # last few turns is enough context
        transcript = "\n".join(f"{role}: {text}" for role, text in recent)

        classifier_prompt = (
            "You are a strict scope classifier for a LEGACY IT SYSTEM SUPPORT "
            "assistant (error troubleshooting, navigation help, workflow "
            "guidance, access-request routing, and directly related "
            "follow-ups like 'yes escalate it' or 'that fixed it' in an "
            "ongoing support conversation).\n\n"
            f"Recent conversation (may be empty):\n{transcript}\n\n"
            f"Latest user message: {state['user_query']}\n\n"
            "Is the LATEST user message legacy-system-support-related "
            "(including a short follow-up/confirmation to an ongoing support "
            "conversation, or a greeting)? Answer with exactly one word: "
            "SUPPORT or OFF_TOPIC."
        )
        try:
            llm = get_fast_llm(temperature=0.0)
            verdict = llm.invoke([HumanMessage(content=classifier_prompt)]).content.strip().upper()
        except Exception:
            verdict = "SUPPORT"  # fail open on classifier errors, don't block the user

        if "OFF_TOPIC" in verdict:
            state["off_topic"] = True
            state["blocked"] = True
            state["final_answer"] = (
                "I'm your legacy-system support assistant, so I can only help with "
                "issues on our supported systems - errors, navigation, workflows, "
                "and escalations. Happy to help troubleshoot whenever you're ready!"
            )
        else:
            state["off_topic"] = False
        return state

    def _node_react_agent(self, state: LegacySupportGraphState) -> LegacySupportGraphState:
        if state.get("blocked"):
            return state

        # Rebuild the full conversation as alternating Human/AI messages so
        # the agent has real memory of prior turns, instead of only ever
        # seeing the current message in isolation.
        messages = []
        for role, text in (state.get("chat_history") or []):
            if role == "user":
                messages.append(HumanMessage(content=text))
            else:
                messages.append(AIMessage(content=text))

        current_query = state["user_query"]
        if state.get("session_context"):
            current_query = (
                f"{state['user_query']}\n\n"
                f"[Additional context from uploaded documents/screenshots]\n"
                f"{state['session_context']}"
            )
        messages.append(HumanMessage(content=current_query))

        result = self._react_agent.invoke({"messages": messages})
        state["messages"] = result["messages"]
        state["final_answer"] = result["messages"][-1].content
        return state

    def _node_output_guardrail(self, state: LegacySupportGraphState) -> LegacySupportGraphState:
        if state.get("blocked"):
            return state

        answer = state.get("final_answer", "")
        # Lightweight output-side safety net: strip accidental leakage of
        # system-prompt-like text and flag empty responses.
        if not answer or not answer.strip():
            state["final_answer"] = (
                "I wasn't able to generate a complete answer from the available "
                "tools - could you share a bit more detail (which system, and the "
                "exact error message or menu you're on)?"
            )
        if state.get("warnings"):
            note = " ".join(state["warnings"])
            state["final_answer"] = f"{state['final_answer']}\n\n_Note: {note}_"
        return state

    def _build_graph(self):
        graph = StateGraph(LegacySupportGraphState)
        graph.add_node("input_guardrail", self._node_input_guardrail)
        graph.add_node("scope_guardrail", self._node_scope_guardrail)
        graph.add_node("react_agent", self._node_react_agent)
        graph.add_node("output_guardrail", self._node_output_guardrail)

        graph.set_entry_point("input_guardrail")

        def route_after_input_guardrail(state: LegacySupportGraphState):
            return "output_guardrail" if state.get("blocked") else "scope_guardrail"

        def route_after_scope_guardrail(state: LegacySupportGraphState):
            return "output_guardrail" if state.get("blocked") else "react_agent"

        graph.add_conditional_edges("input_guardrail", route_after_input_guardrail,
                                     {"scope_guardrail": "scope_guardrail", "output_guardrail": "output_guardrail"})
        graph.add_conditional_edges("scope_guardrail", route_after_scope_guardrail,
                                     {"react_agent": "react_agent", "output_guardrail": "output_guardrail"})
        graph.add_edge("react_agent", "output_guardrail")
        graph.add_edge("output_guardrail", END)

        return graph.compile()

    # ---- public API --------------------------------------------------
    def run(self, query: str, session_context: str = "", chat_history: list | None = None) -> dict:
        initial_state: LegacySupportGraphState = {
            "user_query": query,
            "session_context": session_context,
            "chat_history": chat_history or [],
            "warnings": [],
        }
        final_state = self.graph.invoke(initial_state)
        return {
            "answer": final_state.get("final_answer", ""),
            "blocked": final_state.get("blocked", False),
            "off_topic": final_state.get("off_topic", False),
            "warnings": final_state.get("warnings", []),
        }


def build_agent() -> LegacySupportAgent:
    return LegacySupportAgent()
