"""
config.py
---------
Central place for LLM / embedding client construction.

Mirrors the pattern already used across the TCS Agentic AI reference apps
(TCS GenAI Lab gateway, OpenAI-compatible), made environment-driven so the
same code runs against:
  - TCS GenAI Lab gateway (corporate LLM gateway)
  - Vanilla OpenAI
  - Any other OpenAI-compatible endpoint (Azure OpenAI, vLLM, Ollama, etc.)

Nothing here talks to the network at import time - clients are built lazily.
"""

import os
import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from dotenv import load_dotenv
load_dotenv()
# ---------------------------------------------------------------------------
# Environment configuration (override via .env or real environment variables)
# ---------------------------------------------------------------------------
API_KEY = os.environ.get("LLM_API_KEY", "sk-qCp1_GpqDDQ0i9iD08GrTw")
BASE_URL = os.environ.get("LLM_BASE_URL", "https://genailab.tcs.in")
CHAT_MODEL = os.environ.get("LLM_CHAT_MODEL", "azure/genailab-maas-gpt-4o-mini")
EMBED_MODEL = os.environ.get("LLM_EMBED_MODEL", "azure/genailab-maas-text-embedding-3-large")

# Corporate networks often sit behind TLS-inspecting proxies -> disable verify
# the same way the reference agent does. Toggle with LLM_TLS_VERIFY=true in
# real prod.
VERIFY_TLS = os.environ.get("LLM_TLS_VERIFY", "false").lower() == "true"

TIKTOKEN_CACHE_DIR = os.environ.get("TIKTOKEN_CACHE_DIR", "./token")
os.environ["TIKTOKEN_CACHE_DIR"] = TIKTOKEN_CACHE_DIR

_http_client = httpx.Client(verify=VERIFY_TLS, timeout=60.0)


def get_llm(temperature: float = 0.2, streaming: bool = False):
    """Return the primary reasoning / dialog-management LLM used by the agent graph."""
    return ChatOpenAI(
        base_url=BASE_URL,
        model=CHAT_MODEL,
        api_key=API_KEY,
        http_client=_http_client,
        temperature=temperature,
        streaming=streaming,
    )


def get_fast_llm(temperature: float = 0.0):
    """
    A cheaper/faster model for lightweight tasks (guardrail rewriting,
    query classification, summarizing tool output). Falls back to the
    main model if no override is configured.
    """
    fast_model = os.environ.get("LLM_FAST_MODEL", CHAT_MODEL)
    return ChatOpenAI(
        base_url=BASE_URL,
        model=fast_model,
        api_key=API_KEY,
        http_client=_http_client,
        temperature=temperature,
    )


def get_embeddings():
    """Embeddings client used for the RAG / legacy-systems knowledge-base vector store."""
    return OpenAIEmbeddings(
        base_url=BASE_URL,
        model=EMBED_MODEL,
        api_key=API_KEY,
        http_client=_http_client,
    )


# ---------------------------------------------------------------------------
# Runtime feature flags (surfaced in the Streamlit sidebar)
# ---------------------------------------------------------------------------
FEATURE_FLAGS = {
    "guardrails_enabled": os.environ.get("ENABLE_GUARDRAILS", "true").lower() == "true",
    "speech_to_text_enabled": os.environ.get("ENABLE_STT", "true").lower() == "true",
    "ocr_enabled": os.environ.get("ENABLE_OCR", "true").lower() == "true",
    "mcp_enabled": os.environ.get("ENABLE_MCP", "true").lower() == "true",
}

VECTOR_DB_DIR = os.environ.get("VECTOR_DB_DIR", "vectordb")
KNOWLEDGE_FILE = os.environ.get("KNOWLEDGE_FILE", "data/legacy_systems_knowledge.txt")
