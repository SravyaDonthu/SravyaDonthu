import os
import httpx
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

API_KEY = "sk-KC-vYapwC0EJlJIhaHjdVA"
BASE_URL = "https://genailab.tcs.in"

tiktoken_cache_dir = "./token"
os.environ["TIKTOKEN_CACHE_DIR"] = tiktoken_cache_dir

client = httpx.Client(verify=False)

def get_llm():
    return ChatOpenAI(
        base_url=BASE_URL,
        model="azure_ai/genailab-maas-DeepSeek-R1",
        api_key=API_KEY,
        http_client=client,
        temperature=0
    )

def get_embeddings():
    return OpenAIEmbeddings(
        base_url=BASE_URL,
        model="azure/genailab-maas-text-embedding-3-large",
        api_key=API_KEY,
        http_client=client
    )
