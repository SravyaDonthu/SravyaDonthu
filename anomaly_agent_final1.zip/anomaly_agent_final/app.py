import streamlit as st
from agents.anomaly_agent import build_agent

st.title("Agentic AI Data Pipeline Anomaly Investigator")

agent = build_agent()

query = """
Analyze pipeline logs and metrics.
Detect anomalies and provide root cause and solution.
"""

if st.button("Analyze Pipeline"):

    result = agent.run(query)

    st.subheader("AI Investigation Report")
    st.write(result)