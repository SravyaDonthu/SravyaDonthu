from langchain_community.vectorstores import Chroma
from langchain_text_splitters import CharacterTextSplitter
from config import get_embeddings

def build_vectordb():

    with open("data/incidents.txt") as f:
        text = f.read()

    splitter = CharacterTextSplitter(
        chunk_size=200,
        chunk_overlap=20
    )

    docs = splitter.split_text(text)

    embeddings = get_embeddings()

    vectordb = Chroma.from_texts(
        docs,
        embedding=embeddings,
        persist_directory="vectordb"
    )

    return vectordb
