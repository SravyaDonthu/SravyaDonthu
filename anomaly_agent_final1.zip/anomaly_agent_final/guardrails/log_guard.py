import json
from guardrails import Guard

def validate_logs():

    guard = Guard.from_rail("guardrails/log_validation_rail.xml")

    with open("data/synthetic_logs.json") as f:
        logs = json.load(f)

    validated = []

    for log in logs:
        output, _ = guard.parse(
            llm_output=json.dumps(log)
        )
        validated.append(output)

    return validated
