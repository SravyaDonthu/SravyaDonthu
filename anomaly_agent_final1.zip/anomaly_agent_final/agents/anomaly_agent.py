from tools.log_parser_tool import parse_logs
from tools.metric_parser_tool import parse_metrics
from tools.anomaly_detection_tool import detect_anomalies
from tools.rag_tool import retrieve_context
from config import get_llm


class AnomalyAgent:

    def __init__(self):
        self.llm = get_llm()

    def run(self, query):

        logs = parse_logs()
        metrics = parse_metrics()
        anomalies = detect_anomalies()
        context = retrieve_context()

        prompt = f"""
You are a senior data engineering AI investigator.



Pipeline Metrics:
{metrics}

Detected Anomalies:
{anomalies}

Historical Knowledge:
{context}

User Query:
{query}

Provide response in this format:

Anomaly Summary
Metric Evidence
Root Cause
Impact
Recommended Solution
Prevention Strategy
Severity
"""

        response = self.llm.invoke(prompt)

        return response.content


def build_agent():
    return AnomalyAgent()