import pandas as pd
#from guardrails.log_guard import validate_logs
import json

def parse_logs():
   #logs = validate_logs()
   with open("data/synthetic_logs.json") as f:
       logs = json.load(f)
   df = pd.DataFrame(logs)
   return df.to_string()
