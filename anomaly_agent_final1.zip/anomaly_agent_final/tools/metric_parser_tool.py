import json
import pandas as pd

def parse_metrics():
    with open("data/pipeline_metrics.json") as f:
        metrics = json.load(f)

    df = pd.DataFrame(metrics)
    return df.to_string()
