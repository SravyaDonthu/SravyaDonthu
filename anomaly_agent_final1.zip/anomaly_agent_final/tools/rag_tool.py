from rag.vectordb import build_vectordb

def retrieve_context():
    vectordb = build_vectordb()
    docs = vectordb.similarity_search("data pipeline anomaly root cause")
    return docs[0].page_content
